import { ChargingStation } from '@/types/station';
import { LatLng } from '@/types/map';
import { RouteInfo } from '@/types/route';
import { directionsService } from './directionsService';
import { placesEVService } from './placesEVService';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';

export interface EnrichedStation extends ChargingStation {
    distanceText?: string;
    durationText?: string;
    distanceMeters?: number;
    durationSeconds?: number;
    polyline?: string;
}

export async function fetchNearbyStations(
    userLocation: LatLng,
    radiusMeters: number = 25000 // Increased to 25km for better coverage
): Promise<EnrichedStation[]> {
    try {
        console.log('🔍 Fetching real EV charging stations from Google Places API...');
        console.log('📍 User location:', userLocation);
        console.log('📏 Search radius:', radiusMeters / 1000, 'km');

        // Fetch real data from Google Places API only
        const stations: ChargingStation[] = await placesEVService.fetchRealChargingStations(userLocation, radiusMeters);
        console.log(`✅ Found ${stations.length} real charging stations`);

        // Filter by radius using spherical distance
        const nearbyStations = stations
            .map((station) => {
                const distance = computeDistance(userLocation, station.location);
                return {
                    ...station,
                    distance: distance / 1000, // Convert to km for display
                    distanceMeters: distance,
                };
            })
            .filter((station) => station.distanceMeters! <= radiusMeters)
            .sort((a, b) => a.distanceMeters! - b.distanceMeters!);

        // Take top 8 nearest for detailed route info (to save API quota)
        const topNearest = nearbyStations.slice(0, 8);
        const remaining = nearbyStations.slice(8);

        // Get accurate route info for top 8
        const routeInfoPromises = topNearest.map((station) =>
            directionsService.getRouteInfo(userLocation, station.location)
        );

        const routeInfos = await Promise.all(routeInfoPromises);

        // Enrich top stations with route info
        const enrichedTop: EnrichedStation[] = topNearest.map((station, index) => {
            const routeInfo = routeInfos[index];
            if (routeInfo) {
                return {
                    ...station,
                    distanceText: routeInfo.distanceText,
                    durationText: routeInfo.durationText,
                    distanceMeters: routeInfo.distanceMeters,
                    durationSeconds: routeInfo.durationSeconds,
                    polyline: routeInfo.polyline,
                };
            }
            // Fallback to spherical distance
            return {
                ...station,
                distanceText: `${station.distance!.toFixed(1)} km`,
                durationText: 'ETA unavailable',
            };
        });

        // Add remaining with spherical distance only
        const enrichedRemaining: EnrichedStation[] = remaining.map((station) => ({
            ...station,
            distanceText: `${station.distance!.toFixed(1)} km`,
            durationText: 'ETA unavailable',
        }));

        return [...enrichedTop, ...enrichedRemaining];
    } catch (error) {
        console.error('Error fetching nearby stations:', error);
        throw error;
    }
}



// Compute spherical distance between two points (Haversine formula)
function computeDistance(point1: LatLng, point2: LatLng): number {
    if (typeof google !== 'undefined' && google.maps?.geometry) {
        const p1 = new google.maps.LatLng(point1.lat, point1.lng);
        const p2 = new google.maps.LatLng(point2.lat, point2.lng);
        return google.maps.geometry.spherical.computeDistanceBetween(p1, p2);
    }

    // Fallback Haversine formula
    const R = 6371e3; // Earth radius in meters
    const φ1 = (point1.lat * Math.PI) / 180;
    const φ2 = (point2.lat * Math.PI) / 180;
    const Δφ = ((point2.lat - point1.lat) * Math.PI) / 180;
    const Δλ = ((point2.lng - point1.lng) * Math.PI) / 180;

    const a =
        Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
        Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c;
}

export async function fetchNearbyStationsInBounds(
    userLocation: LatLng,
    bounds: google.maps.LatLngBounds
): Promise<EnrichedStation[]> {
    try {
        console.log('🗺️ Fetching stations in bounds...');

        // Fetch real data from Google Places API using bounds
        const stations: ChargingStation[] = await placesEVService.fetchRealChargingStationsInBounds(bounds);
        console.log(`✅ Found ${stations.length} stations in current view`);

        // Calculate distance from user to each station for sorting
        const stationsWithDistance = stations
            .map((station) => {
                const distance = computeDistance(userLocation, station.location);
                return {
                    ...station,
                    distance: distance / 1000, // Convert to km for display
                    distanceMeters: distance,
                };
            })
            .sort((a, b) => a.distanceMeters! - b.distanceMeters!);

        // Take top 8 nearest for detailed route info (to save API quota)
        const topNearest = stationsWithDistance.slice(0, 8);
        const remaining = stationsWithDistance.slice(8);

        // Get accurate route info for top 8
        const routeInfoPromises = topNearest.map((station) =>
            directionsService.getRouteInfo(userLocation, station.location)
        );

        const routeInfos = await Promise.all(routeInfoPromises);

        // Enrich top stations with route info
        const enrichedTop: EnrichedStation[] = topNearest.map((station, index) => {
            const routeInfo = routeInfos[index];
            if (routeInfo) {
                return {
                    ...station,
                    distanceText: routeInfo.distanceText,
                    durationText: routeInfo.durationText,
                    distanceMeters: routeInfo.distanceMeters,
                    durationSeconds: routeInfo.durationSeconds,
                    polyline: routeInfo.polyline,
                };
            }
            // Fallback to spherical distance
            return {
                ...station,
                distanceText: `${station.distance!.toFixed(1)} km`,
                durationText: 'ETA unavailable',
            };
        });

        // Add remaining with spherical distance only
        const enrichedRemaining: EnrichedStation[] = remaining.map((station) => ({
            ...station,
            distanceText: `${station.distance!.toFixed(1)} km`,
            durationText: 'ETA unavailable',
        }));

        return [...enrichedTop, ...enrichedRemaining];
    } catch (error) {
        console.error('Error fetching stations in bounds:', error);
        throw error;
    }
}

export async function searchStations(query: string): Promise<ChargingStation[]> {
    try {
        const response = await fetch(`${API_URL}/api/stations/search/${encodeURIComponent(query)}`);
        if (!response.ok) {
            console.warn('Station search failed:', response.status);
            return [];
        }
        const text = await response.text();
        if (!text) return [];
        const data = JSON.parse(text);
        return data.success ? data.stations : [];
    } catch (error) {
        console.error('Error searching stations:', error);
        return [];
    }
}
