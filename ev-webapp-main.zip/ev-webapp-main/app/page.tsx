'use client';

import dynamic from 'next/dynamic';
import Navbar from '@/components/Layout/Navbar';
import Sidebar from '@/components/Layout/Sidebar';
import BottomBar from '@/components/Layout/BottomBar';

// Dynamically import map component (client-side only)
const MapContainer = dynamic(() => import('@/components/Map/MapContainer'), {
    ssr: false,
    loading: () => (
        <div className="w-full h-screen flex items-center justify-center bg-gray-100 dark:bg-gray-900">
            <div className="text-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mx-auto mb-4"></div>
                <p className="text-gray-600 dark:text-gray-400">Loading map...</p>
            </div>
        </div>
    ),
});

export default function Home() {
    // Stations are now loaded from Google Places API in MapContainer.tsx
    // when user location is available

    return (
        <main className="relative w-full h-screen overflow-hidden">
            {/* Navbar */}
            <div className="pointer-events-auto">
                <Navbar />
            </div>

            {/* Sidebar */}
            <div className="pointer-events-auto">
                <Sidebar />
            </div>

            {/* Map is now in layout.tsx for persistence */}

            {/* Mobile Bottom Navigation */}
            <div className="pointer-events-auto">
                <BottomBar />
            </div>
        </main>
    );
}
