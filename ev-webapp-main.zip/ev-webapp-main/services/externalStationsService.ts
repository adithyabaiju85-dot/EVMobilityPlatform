import axios from 'axios';
import { ChargingStation } from '@/types/station';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';

interface ExternalStationResponse {
    source: 'google' | 'openchargemap' | 'osm' | 'simulated';
    stations: ExternalStation[];
    meta: any;
}

interface ExternalStation {
    id: string;
    source: string;
    name: string;
    location: { lat: number; lng: number };
    address: string;
    connectors: { type: string; powerKW?: number }[];
    status: 'available' | 'busy' | 'unknown';
    raw: any;
}

class ExternalStationsService {

    private cache = new Map<string, { timestamp: number, data: ChargingStation[], ttl?: number }>();
    private pendingRequests = new Map<string, Promise<ChargingStation[]>>();
    private CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutes default
    private ERROR_TTL_MS = 30 * 1000; // 30 seconds for errors

    async fetchStationsInBounds(
        bounds: google.maps.LatLngBounds,
        userLocation?: { lat: number; lng: number }
    ): Promise<ChargingStation[]> {
        const cacheKey = this.getCacheKey(bounds);

        // 1. Check In-Flight Requests (Deduplication)
        if (this.pendingRequests.has(cacheKey)) {
            // console.log(`🔄 [StationCache] Request already IN FLIGHT for ${cacheKey}, reusing promise.`);
            return this.pendingRequests.get(cacheKey)!;
        }

        // 2. Check Cache
        const cached = this.cache.get(cacheKey);
        if (cached) {
            const ttl = cached.ttl || this.CACHE_TTL_MS;
            if (Date.now() - cached.timestamp < ttl) {
                // console.log(`📦 [StationCache] Hit for ${cacheKey} (${cached.data.length} stations)`);
                return cached.data;
            }
        }

        // 3. Perform Fetch
        console.log(`🌍 [StationCache] Miss for ${cacheKey}, fetching from API...`);
        const fetchPromise = this.fetchFromApi(bounds, userLocation, cacheKey);

        this.pendingRequests.set(cacheKey, fetchPromise);

        try {
            const result = await fetchPromise;
            return result;
        } finally {
            this.pendingRequests.delete(cacheKey);
        }
    }

    private async fetchFromApi(
        bounds: google.maps.LatLngBounds,
        userLocation: { lat: number; lng: number } | undefined,
        key: string
    ): Promise<ChargingStation[]> {
        try {
            const ne = bounds.getNorthEast();
            const sw = bounds.getSouthWest();
            const center = bounds.getCenter();

            const params = {
                lat: userLocation?.lat || center.lat(),
                lng: userLocation?.lng || center.lng(),
                north: ne.lat(),
                south: sw.lat(),
                east: ne.lng(),
                west: sw.lng(),
                radius: 15000 // Default search radius
            };

            const response = await axios.get<ExternalStationResponse>(`${API_URL}/api/external-stations`, {
                params,
                timeout: 10000 // 10s timeout to prevent hanging
            });

            console.log(`✅ Backend returned ${response.data.stations.length} stations from: ${response.data.source}`);

            // Convert
            const stations = response.data.stations.map(this.convertToInternalFormat);

            // Update Cache (Standard TTL)
            this.cache.set(key, { timestamp: Date.now(), data: stations });

            this.pruneCache();

            return stations;

        } catch (error) {
            console.error('❌ Failed to fetch external stations (Caching empty result for 30s):', error);

            // Negative Caching: Prevent retry loops by caching empty result for short time
            this.cache.set(key, {
                timestamp: Date.now(),
                data: [],
                ttl: this.ERROR_TTL_MS
            });

            return [];
        }
    }

    private pruneCache() {
        if (this.cache.size > 50) {
            const oldestKey = this.cache.keys().next().value;
            if (oldestKey) this.cache.delete(oldestKey);
        }
    }

    private getCacheKey(bounds: google.maps.LatLngBounds): string {
        // Standardize bounds to prevent flip-flopping keys
        const ne = bounds.getNorthEast();
        const sw = bounds.getSouthWest();

        // Ensure lat is clamped -90 to 90, lng -180 to 180 (basic normalization)
        // Fixed precision 3 decimals (~100m)
        const n = ne.lat().toFixed(3);
        const e = ne.lng().toFixed(3);
        const s = sw.lat().toFixed(3);
        const w = sw.lng().toFixed(3);

        return `${n}_${e}_${s}_${w}`;
    }

    private convertToInternalFormat(ext: ExternalStation): ChargingStation {
        // Map external status to internal status
        let validStatus: ChargingStation['status'] = 'offline';
        if (ext.status === 'available') validStatus = 'available';
        else if (ext.status === 'busy') validStatus = 'busy';
        else if (ext.status === 'unknown') validStatus = 'offline'; // Explicitly handle unknown

        // Generate connectors if missing (common for Google Places)
        const connectors = ext.connectors && ext.connectors.length > 0
            ? ext.connectors.map((c, i) => ({
                id: `${ext.id}-conn-${i}`,
                type: c.type,
                power: c.powerKW || 22,
                available: true,
                price: 0.35
            }))
            : [
                { id: `${ext.id}-c1`, type: 'Type2' as any, power: 22, available: true, price: 0.30 },
                { id: `${ext.id}-c2`, type: 'CCS' as any, power: 50, available: true, price: 0.45 }
            ];

        return {
            id: ext.id,
            name: ext.name,
            location: ext.location,
            address: ext.address,
            status: validStatus,
            connectors: connectors as any, // Cast to internal type
            amenities: {
                wifi: false,
                restaurant: false,
                restroom: false,
                parking: true,
                shelter: false
            },
            rating: 4.5, // Default/Placeholder
            reviews: 0,
            speed: connectors.some(c => c.power > 50) ? 'fast' : 'slow',
            operator: 'External Network',
            operatingHours: '24/7',
            source: ext.source as any
        };
    }
}

export const externalStationsService = new ExternalStationsService();
