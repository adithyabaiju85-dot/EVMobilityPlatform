// Load environment variables
require('dotenv').config({ path: '.env' });

const { Pool } = require('pg');
const { PrismaPg } = require('@prisma/adapter-pg');
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcrypt');

// Prisma 7+ requires driver adapter
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const adapter = new PrismaPg(pool);
const prisma = new PrismaClient({ adapter });

// Helper to get dates relative to now
const now = new Date();
const hoursAgo = (h) => new Date(now.getTime() - h * 60 * 60 * 1000);
const hoursLater = (h) => new Date(now.getTime() + h * 60 * 60 * 1000);
const daysAgo = (d) => new Date(now.getTime() - d * 24 * 60 * 60 * 1000);

async function main() {
    console.log('🌱 Starting seed...');

    // ============================================
    // USERS
    // ============================================
    const adminPassword = 'Admin@123';
    const userPassword = 'User@123';

    const adminHash = await bcrypt.hash(adminPassword, 10);
    const userHash = await bcrypt.hash(userPassword, 10);

    const admin = await prisma.user.upsert({
        where: { email: 'admin@evcharge.com' },
        update: {},
        create: {
            name: 'Admin User',
            email: 'admin@evcharge.com',
            passwordHash: adminHash,
            role: 'ADMIN',
        },
    });

    const user1 = await prisma.user.upsert({
        where: { email: 'john.doe@example.com' },
        update: {},
        create: {
            name: 'John Doe',
            email: 'john.doe@example.com',
            passwordHash: userHash,
            role: 'USER',
        },
    });

    const user2 = await prisma.user.upsert({
        where: { email: 'jane.smith@example.com' },
        update: {},
        create: {
            name: 'Jane Smith',
            email: 'jane.smith@example.com',
            passwordHash: userHash,
            role: 'USER',
        },
    });

    console.log('✅ Users created');

    // ============================================
    // STATIONS (Bangalore area coordinates)
    // ============================================
    const stationsData = [
        { name: 'MG Road EV Hub', lat: 12.9716, lng: 77.5946, address: 'MG Road, Bangalore' },
        { name: 'Koramangala Charge Point', lat: 12.9352, lng: 77.6245, address: 'Koramangala 4th Block, Bangalore' },
        { name: 'HSR Layout Station', lat: 12.9121, lng: 77.6446, address: 'HSR Layout Sector 2, Bangalore' },
        { name: 'Whitefield Power Station', lat: 12.9698, lng: 77.7500, address: 'Whitefield Main Road, Bangalore' },
        { name: 'Indiranagar Supercharger', lat: 12.9784, lng: 77.6408, address: '100 Feet Road, Indiranagar' },
    ];

    const stations = [];
    for (const s of stationsData) {
        const station = await prisma.station.create({ data: s });
        stations.push(station);
    }

    console.log('✅ Stations created');

    // ============================================
    // CONNECTORS (2-3 per station)
    // ============================================
    const connectorTypes = ['Type 2', 'CCS', 'CHAdeMO'];
    const connectors = [];

    for (const station of stations) {
        const numConnectors = Math.floor(Math.random() * 2) + 2; // 2-3 connectors
        for (let i = 0; i < numConnectors; i++) {
            const connector = await prisma.connector.create({
                data: {
                    stationId: station.id,
                    connectorType: connectorTypes[i % connectorTypes.length],
                    powerKw: [22, 50, 150][i % 3],
                    slotCount: Math.floor(Math.random() * 3) + 2, // 2-4 slots
                },
            });
            connectors.push(connector);
        }
    }

    console.log('✅ Connectors created');

    // ============================================
    // VEHICLES
    // ============================================
    const vehiclesData = [
        { vehicleType: 'CAR', model: 'Tesla Model 3', externalVehicleId: 'TESLA-M3-001' },
        { vehicleType: 'CAR', model: 'Tata Nexon EV', externalVehicleId: 'TATA-NEXON-001' },
        { vehicleType: 'SCOOTER', model: 'Ola S1 Pro', externalVehicleId: 'OLA-S1P-001' },
        { vehicleType: 'SCOOTER', model: 'Ather 450X', externalVehicleId: 'ATHER-450X-001' },
        { vehicleType: 'BIKE', model: 'Revolt RV400', externalVehicleId: 'REVOLT-RV400-001' },
    ];

    const vehicles = [];
    for (const v of vehiclesData) {
        const vehicle = await prisma.vehicle.create({
            data: {
                ...v,
                metadata: { brand: v.model.split(' ')[0], year: 2024 },
            },
        });
        vehicles.push(vehicle);
    }

    console.log('✅ Vehicles created');

    // ============================================
    // BOOKINGS
    // ============================================

    // 1. Active Booking (currently charging)
    const activeBooking = await prisma.booking.create({
        data: {
            userId: user1.id,
            stationId: stations[0].id,
            connectorId: connectors[0].id,
            vehicleId: vehicles[0].id,
            status: 'CONFIRMED',
            slotStart: hoursAgo(1),
            slotEnd: hoursLater(1),
            expiresAt: hoursLater(2),
            amountCents: 15000, // ₹150
            energyKwh: 25.5,
        },
    });

    // 2. Expired Booking (ended yesterday)
    const expiredBooking = await prisma.booking.create({
        data: {
            userId: user1.id,
            stationId: stations[1].id,
            connectorId: connectors[2].id,
            vehicleId: vehicles[1].id,
            status: 'EXPIRED',
            slotStart: daysAgo(1),
            slotEnd: new Date(daysAgo(1).getTime() + 2 * 60 * 60 * 1000),
            expiresAt: daysAgo(1),
            amountCents: 0,
            energyKwh: 0,
        },
    });

    // 3. Cancelled Booking
    const cancelledBooking = await prisma.booking.create({
        data: {
            userId: user2.id,
            stationId: stations[2].id,
            connectorId: connectors[4].id,
            vehicleId: vehicles[2].id,
            status: 'CANCELLED',
            slotStart: daysAgo(2),
            slotEnd: new Date(daysAgo(2).getTime() + 1 * 60 * 60 * 1000),
            expiresAt: daysAgo(2),
            amountCents: 0,
            energyKwh: 0,
        },
    });

    // 4. Completed Booking (for payment history - last week)
    const completedBooking1 = await prisma.booking.create({
        data: {
            userId: user2.id,
            stationId: stations[3].id,
            connectorId: connectors[6].id,
            vehicleId: vehicles[3].id,
            status: 'CONFIRMED',
            slotStart: daysAgo(7),
            slotEnd: new Date(daysAgo(7).getTime() + 2 * 60 * 60 * 1000),
            expiresAt: daysAgo(6),
            amountCents: 22000, // ₹220
            energyKwh: 40.0,
        },
    });

    // 5. Completed Booking (yesterday)
    const completedBooking2 = await prisma.booking.create({
        data: {
            userId: user1.id,
            stationId: stations[4].id,
            connectorId: connectors[8].id,
            vehicleId: vehicles[4].id,
            status: 'CONFIRMED',
            slotStart: daysAgo(1),
            slotEnd: new Date(daysAgo(1).getTime() + 1.5 * 60 * 60 * 1000),
            expiresAt: daysAgo(1),
            amountCents: 18000, // ₹180
            energyKwh: 32.0,
        },
    });

    console.log('✅ Bookings created');

    // ============================================
    // PAYMENTS
    // ============================================

    // Payment for active booking (today)
    await prisma.payment.create({
        data: {
            bookingId: activeBooking.id,
            status: 'COMPLETED',
            amountCents: 15000,
            providerRef: 'PAY-TODAY-001',
            createdAt: now,
        },
    });

    // Payment for completed booking (last week)
    await prisma.payment.create({
        data: {
            bookingId: completedBooking1.id,
            status: 'COMPLETED',
            amountCents: 22000,
            providerRef: 'PAY-WEEK-001',
            createdAt: daysAgo(7),
        },
    });

    // Payment for completed booking (yesterday)
    await prisma.payment.create({
        data: {
            bookingId: completedBooking2.id,
            status: 'COMPLETED',
            amountCents: 18000,
            providerRef: 'PAY-YEST-001',
            createdAt: daysAgo(1),
        },
    });

    console.log('✅ Payments created');

    // ============================================
    // AUDIT LOG
    // ============================================
    await prisma.audit.create({
        data: {
            entityType: 'Booking',
            entityId: activeBooking.id,
            action: 'CREATE',
            data: { userId: user1.id, stationId: stations[0].id },
        },
    });

    console.log('✅ Audit log created');

    // ============================================
    // SUMMARY
    // ============================================
    console.log('\n========================================');
    console.log('🎉 SEED COMPLETED SUCCESSFULLY!');
    console.log('========================================');
    console.log('\n📧 ADMIN CREDENTIALS:');
    console.log(`   Email:    admin@evcharge.com`);
    console.log(`   Password: ${adminPassword}`);
    console.log('\n📧 USER CREDENTIALS:');
    console.log(`   Email:    john.doe@example.com`);
    console.log(`   Password: ${userPassword}`);
    console.log('========================================\n');
}

main()
    .catch((e) => {
        console.error('❌ Seed failed:', e);
        process.exit(1);
    })
    .finally(async () => {
        await prisma.$disconnect();
    });
