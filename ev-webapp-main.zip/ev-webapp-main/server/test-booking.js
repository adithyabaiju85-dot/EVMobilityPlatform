const prisma = require('./lib/prisma');
const bookingService = require('./services/bookingService');

async function testBooking() {
    try {
        console.log("🔍 Finding a User...");
        const user = await prisma.user.findFirst();
        if (!user) {
            console.error("❌ No users found in DB. Please seed users first.");
            return;
        }
        console.log(`✅ Using User: ${user.email} (${user.id})`);

        console.log("🔍 Finding a Station...");
        const station = await prisma.station.findFirst({ include: { connectors: true } });
        if (!station) {
            console.error("❌ No stations found in DB.");
            return;
        }
        console.log(`✅ Using Station: ${station.name} (${station.id})`);
        console.log(`   Connectors: ${station.connectors.length}`);

        if (station.connectors.length === 0) {
            console.error("❌ Station has no connectors! Cannot book.");
            return;
        }

        console.log("🚀 Attempting to create booking...");
        const booking = await bookingService.createBooking({
            stationId: station.id,
            userId: user.id,
            vehicleModel: 'Tesla Model 3',
            slotStart: new Date().toISOString(),
            durationMinutes: 30
        });

        console.log("✅ Booking Created Successfully!");
        console.log(JSON.stringify(booking, null, 2));
    } catch (error) {
        console.error("💥 Booking Failed!");
        console.error("Error Name:", error.name);
        console.error("Error Message:", error.message);
        if (error.code) console.error("Error Code:", error.code);
        if (error.meta) console.error("Error Meta:", error.meta);
        console.error("Full Error:", error);
    } finally {
        await prisma.$disconnect();
    }
}

testBooking();
