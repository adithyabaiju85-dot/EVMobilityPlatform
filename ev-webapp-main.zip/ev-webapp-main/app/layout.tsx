import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import MapContainer from "@/components/Map/MapContainer";
import StationDrawer from "@/components/Stations/StationDrawer";
import SplashProvider from "@/components/SplashProvider";

const inter = Inter({
    subsets: ["latin"],
    variable: "--font-inter",
    display: "swap",
});

export const metadata: Metadata = {
    title: "TORQ EV - Smart EV Charging Network",
    description: "Discover, book, and navigate to EV charging stations with intelligent trip planning",
    keywords: "EV charging, electric vehicle, charging stations, trip planner, route optimization, TORQ EV",
    authors: [{ name: "TORQ EV" }],
    manifest: "/manifest.json",
    appleWebApp: {
        capable: true,
        statusBarStyle: "default",
        title: "TORQ EV",
    },
    other: {
        "Content-Security-Policy": "default-src 'self' 'unsafe-inline' 'unsafe-eval' http://localhost:3000 http://localhost:3001 http://127.0.0.1:3001 ws://localhost:3001 https://maps.googleapis.com https://fonts.googleapis.com https://maps.gstatic.com data: blob:;"
    }
};

export const viewport = {
    width: "device-width",
    initialScale: 1,
    themeColor: "#10b981", // Emerald to match TORQ EV branding
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
    return (
        <html lang="en" className={inter.variable} suppressHydrationWarning>
            <body className="antialiased h-screen w-screen overflow-hidden" suppressHydrationWarning>
                <SplashProvider>
                    {/* Persistent Map (client) */}
                    <div id="app-wallpaper" className="fixed inset-0 z-0">
                        <MapContainer />
                    </div>

                    {/* App UI above the map */}
                    <div id="app-content" className="relative z-10 min-h-screen pointer-events-none">
                        <div className="pointer-events-auto">
                            <StationDrawer />
                        </div>
                        {children}
                    </div>
                </SplashProvider>
            </body>
        </html>
    );
}
