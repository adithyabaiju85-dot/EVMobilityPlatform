import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useStationsStore } from '@/store/stationsStore';
import { useRouteStore } from '@/store/routeStore';
import { useMapStore } from '@/store/mapStore';
import { useBookingsStore } from '@/store/bookingsStore';
import { directionsService } from '@/services/directionsService';
import { ChargingStation } from '@/types/station';

import { LatLng } from '@/types/map';

const calculateLocalDistance = (point1: LatLng, point2: LatLng): number => {
    const R = 6371;
    const dLat = (point2.lat - point1.lat) * (Math.PI / 180);
    const dLon = (point2.lng - point1.lng) * (Math.PI / 180);
    const a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(point1.lat * (Math.PI / 180)) * Math.cos(point2.lat * (Math.PI / 180)) *
        Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
};

interface StationCardProps {
    station: ChargingStation;
}

export default function StationCard({ station }: StationCardProps) {
    const { setSelectedStation, setBookingModalOpen } = useStationsStore();
    const { userLocation } = useMapStore();
    const { activeBooking } = useBookingsStore();

    // Check if THIS station is the one currently booked
    const isBooked = activeBooking?.stationId === station.id && activeBooking?.status === 'CONFIRMED';

    // Countdown logic
    const [timeLeft, setTimeLeft] = useState<string>('');

    useEffect(() => {
        if (!isBooked || !activeBooking) {
            setTimeLeft('');
            return;
        }

        // Always show countdown to slotEnd (when charging session ends)
        // This includes arrival time + charging duration, and updates when extended

        const updateTimer = () => {
            const endTime = new Date(activeBooking.slotEnd).getTime();
            const diff = endTime - Date.now();

            if (diff <= 0) {
                setTimeLeft('Completed');
                return;
            }
            const mins = Math.floor(diff / 60000);
            const secs = Math.floor((diff % 60000) / 1000);
            setTimeLeft(`${mins}:${secs.toString().padStart(2, '0')}`);
        };

        updateTimer();
        const interval = setInterval(updateTimer, 1000);
        return () => clearInterval(interval);
    }, [isBooked, activeBooking, activeBooking?.slotEnd]);

    const handleBookAndTrack = (e: React.MouseEvent) => {
        e.stopPropagation();
        setSelectedStation(station);
        setBookingModalOpen(true);
    };

    const handleTrackNow = (e: React.MouseEvent) => {
        e.stopPropagation();
        console.log("🖱️ Track Now clicked for station:", station.name);
        // Do NOT set selectedStation, otherwise the Drawer opens and blocks the map.
        // setSelectedStation(station); 

        if (userLocation) {
            console.log("📍 User location found:", userLocation);
            const { setFollowMode, setIsNavigating, setActiveRoute } = useRouteStore.getState();

            // Optimistic UI update
            setFollowMode(true);
            setIsNavigating(true);

            directionsService.getRouteInfo(userLocation.position, station.location)
                .then(route => {
                    if (route) {
                        setActiveRoute(route);
                    } else {
                        alert("Could not calculate route. Please try again.");
                        setIsNavigating(false);
                    }
                })
                .catch(err => {
                    console.error("Routing failed", err);
                    alert("Routing failed");
                    setIsNavigating(false);
                });
        } else {
            alert("User location not known. Cannot track.");
        }
    };

    // Helper to get speed color
    const getSpeedColor = () => {
        switch (station.speed) {
            case 'ultra-fast': return 'text-purple-600';
            case 'fast': return 'text-primary-600';
            default: return 'text-gray-600';
        }
    };

    return (
        <>
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                whileHover={{ scale: 1.02 }}
                className={`card cursor-pointer hover:scale-[1.02] transition-all duration-300 border-2 ${isBooked ? 'border-primary-500 bg-black/90 shadow-gold-glow' : 'border-gray-800 bg-gray-900/90 shadow-xl'}`}
                onClick={() => setSelectedStation(station)}
            >
                {/* Header */}
                <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                        <h3 className="font-semibold text-gray-900 dark:text-white mb-1">
                            {station.name}
                        </h3>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                            {station.address}
                        </p>
                    </div>
                    {getStatusBadge(station.status)}
                </div>

                {/* Stats */}
                <div className="flex items-center gap-4 mb-3">
                    <div className="flex items-center gap-1">
                        <span className="text-sm font-medium">⭐ {station.rating}</span>
                        <span className="text-xs text-gray-500">({station.reviews})</span>
                    </div>

                    {/* Distance and ETA */}
                    <div className="flex items-center gap-2 text-sm">
                        <span className="text-primary-600 dark:text-primary-400 font-medium">
                            {station.distanceText || (userLocation ? `${calculateLocalDistance(userLocation.position, station.location).toFixed(1)} km` : '-')}
                        </span>
                        <span className="text-gray-400">•</span>
                        <span className="text-gray-600 dark:text-gray-400">
                            {station.durationText || (userLocation ? `~${Math.ceil((calculateLocalDistance(userLocation.position, station.location) / 30) * 60)} min` : 'Unknown')}
                        </span>
                    </div>
                </div>

                {/* Amenities */}
                <div className="flex items-center justify-between mb-3 text-gray-500 text-xs">
                    <div className="flex gap-2">
                        {station.amenities?.wifi && <span>📶 WiFi</span>}
                        {station.amenities?.restaurant && <span>🍽️ Food</span>}
                        {station.amenities?.parking && <span>🅿️ Parking</span>}
                    </div>
                    <span className={`font-bold ${getSpeedColor()}`}>
                        {station.speed === 'ultra-fast' ? '⚡ Ultra Fast' : '⚡ Normal'}
                    </span>
                </div>

                {/* Action Area */}
                <div className="mt-2 flex gap-2">
                    {isBooked ? (
                        <div className="flex-1">
                            <div className="text-xs text-blue-600 font-bold mb-1 uppercase tracking-wider">
                                Slot Reserved
                            </div>
                            <div className="flex gap-2">
                                <div className="bg-white border border-blue-200 px-3 py-2 rounded-lg flex-1 text-center">
                                    <span className="text-lg font-mono font-bold text-blue-700">{timeLeft}</span>
                                    <div className="text-[10px] text-gray-500">until end</div>
                                </div>
                                <button
                                    onClick={handleTrackNow}
                                    className="px-4 py-2 bg-gradient-to-b from-primary-400 to-primary-600 border-t border-primary-300 text-black font-bold rounded-lg shadow-3d hover:shadow-3d-hover active:shadow-none active:translate-y-[2px] animate-pulse"
                                >
                                    Track Now
                                </button>
                            </div>
                        </div>
                    ) : (
                        <button
                            onClick={handleBookAndTrack}
                            disabled={station.status !== 'available'}
                            className={`w-full py-3 rounded-xl font-bold text-white shadow-lg transition-all transform hover:-translate-y-0.5 ${station.status === 'available'
                                ? 'bg-gradient-to-r from-primary-500 to-primary-600 hover:shadow-gold-glow text-black'
                                : 'bg-gray-400 cursor-not-allowed'
                                }`}
                        >
                            {station.status === 'available' ? 'Book & Track' : 'Unavailable'}
                        </button>
                    )}
                </div>
            </motion.div>

        </>
    );
}

function getStatusBadge(status: string) {
    const styles = {
        available: 'bg-green-100 text-green-700 border-green-200',
        busy: 'bg-yellow-100 text-yellow-700 border-yellow-200',
        booked: 'bg-black text-primary-400 border-primary-500 shadow-gold-glow',
        offline: 'bg-gray-100 text-gray-700 border-gray-200'
    };
    const labels = {
        available: 'Available',
        busy: 'Busy',
        booked: 'Booked',
        offline: 'Offline'
    };
    const s = status as keyof typeof styles;
    return (
        <span className={`px-2 py-1 rounded-md text-xs font-bold border ${styles[s] || styles.offline}`}>
            {labels[s] || 'Unknown'}
        </span>
    );
}
