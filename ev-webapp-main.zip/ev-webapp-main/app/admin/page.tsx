'use client';

import { useEffect, useState, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { io, Socket } from 'socket.io-client';

interface DashboardData {
    activeBookingsCount: number;
    totalAvailableSlots: number;
    todayRevenueCents: number;
    weekRevenueCents: number;
    monthRevenueCents: number;
    todayEnergyKwh: number;
    recentBookings: any[];
}

interface Booking {
    id: string;
    user: { name: string; email: string };
    station: { name: string; address?: string; lat?: number; lng?: number };
    vehicle: { vehicleType: string; model: string };
    status: string;
    slotStart: string;
    slotEnd: string;
    remainingSeconds: number;
    amountCents: number;
    energyKwh: number;
}

export default function AdminDashboardPage() {
    const router = useRouter();
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [dashboard, setDashboard] = useState<DashboardData | null>(null);
    const [bookings, setBookings] = useState<Booking[]>([]);
    const [socket, setSocket] = useState<Socket | null>(null);
    const [user, setUser] = useState<any>(null);

    const fetchDashboard = useCallback(async (token: string) => {
        try {
            const res = await fetch('http://localhost:3001/api/admin/dashboard', {
                headers: { Authorization: `Bearer ${token}` },
            });
            if (!res.ok) throw new Error('Failed to fetch dashboard');
            const data = await res.json();
            setDashboard(data);
        } catch (err: any) {
            setError(err.message);
        }
    }, []);

    const fetchBookings = useCallback(async (token: string) => {
        try {
            const res = await fetch('http://localhost:3001/api/admin/current-bookings', {
                headers: { Authorization: `Bearer ${token}` },
            });
            if (!res.ok) throw new Error('Failed to fetch bookings');
            const data = await res.json();
            setBookings(data.bookings);
        } catch (err: any) {
            console.error('Bookings error:', err);
        }
    }, []);

    useEffect(() => {
        const token = localStorage.getItem('adminToken');
        const userStr = localStorage.getItem('adminUser');

        if (!token || !userStr) {
            router.push('/admin/login');
            return;
        }

        try {
            setUser(JSON.parse(userStr));
        } catch {
            router.push('/admin/login');
            return;
        }

        // Fetch initial data
        Promise.all([fetchDashboard(token), fetchBookings(token)]).finally(() => {
            setLoading(false);
        });

        // Setup socket connection
        const newSocket = io('http://localhost:3001', {
            auth: { token },
        });

        newSocket.on('connect', () => {
            console.log('Admin socket connected');
        });

        newSocket.on('booking.created', (booking) => {
            console.log('New booking:', booking);
            setBookings((prev) => [booking, ...prev]);
            fetchDashboard(token);
        });

        newSocket.on('booking.cancelled', (data) => {
            console.log('Booking cancelled:', data);
            setBookings((prev) => prev.filter((b) => b.id !== data.booking.id));
            fetchDashboard(token);
        });

        setSocket(newSocket);

        // Refresh data every 30 seconds
        const interval = setInterval(() => {
            fetchDashboard(token);
            fetchBookings(token);
        }, 30000);

        return () => {
            newSocket.disconnect();
            clearInterval(interval);
        };
    }, [router, fetchDashboard, fetchBookings]);

    const handleLogout = () => {
        localStorage.removeItem('adminToken');
        localStorage.removeItem('adminUser');
        router.push('/admin/login');
    };

    const handleForceCancel = async (bookingId: string) => {
        const token = localStorage.getItem('adminToken');
        if (!token) return;

        try {
            const res = await fetch('http://localhost:3001/api/admin/booking/force-cancel', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify({ bookingId }),
            });

            if (!res.ok) throw new Error('Failed to cancel');
            fetchDashboard(token);
            fetchBookings(token);
        } catch (err: any) {
            alert(err.message);
        }
    };

    const formatCurrency = (cents: number) => {
        return `₹${(cents / 100).toLocaleString('en-IN')}`;
    };

    const formatTime = (seconds: number) => {
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins}m ${secs}s`;
    };

    if (loading) {
        return (
            <div className="min-h-screen bg-gray-900 flex items-center justify-center">
                <div className="text-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
                    <p className="text-gray-400 mt-4">Loading dashboard...</p>
                </div>
            </div>
        );
    }

    if (error) {
        return (
            <div className="min-h-screen bg-gray-900 flex items-center justify-center">
                <div className="text-center">
                    <p className="text-red-400 text-xl">{error}</p>
                    <button onClick={() => router.push('/admin/login')} className="mt-4 text-blue-400 hover:underline">
                        Back to Login
                    </button>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
            {/* Header */}
            <header className="bg-gray-800/50 backdrop-blur-xl border-b border-gray-700 sticky top-0 z-50">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-r from-blue-500 to-cyan-400 flex items-center justify-center">
                            <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                            </svg>
                        </div>
                        <div>
                            <h1 className="text-xl font-bold text-white">Admin Dashboard</h1>
                            <p className="text-sm text-gray-400">Welcome, {user?.name}</p>
                        </div>
                    </div>
                    <button
                        onClick={handleLogout}
                        className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-gray-300 rounded-lg transition-colors"
                    >
                        Logout
                    </button>
                </div>
            </header>

            <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                    <StatCard
                        title="Active Bookings"
                        value={dashboard?.activeBookingsCount || 0}
                        icon="⚡"
                        color="blue"
                    />
                    <StatCard
                        title="Available Slots"
                        value={dashboard?.totalAvailableSlots || 0}
                        icon="🔌"
                        color="green"
                    />
                    <StatCard
                        title="Today Revenue"
                        value={formatCurrency(dashboard?.todayRevenueCents || 0)}
                        icon="💰"
                        color="purple"
                    />
                    <StatCard
                        title="Today Energy"
                        value={`${(dashboard?.todayEnergyKwh || 0).toFixed(1)} kWh`}
                        icon="🔋"
                        color="cyan"
                    />
                </div>

                {/* Quick Actions */}
                <div className="flex justify-end mb-6">
                    <Link
                        href="/admin/history"
                        className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg flex items-center gap-2 transition-colors"
                    >
                        <span>View Full Booking History</span>
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                        </svg>
                    </Link>
                </div>

                {/* Revenue Summary */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
                    <div className="bg-gray-800/50 backdrop-blur-xl rounded-xl border border-gray-700 p-6">
                        <h3 className="text-gray-400 text-sm font-medium mb-2">This Week</h3>
                        <p className="text-2xl font-bold text-white">{formatCurrency(dashboard?.weekRevenueCents || 0)}</p>
                    </div>
                    <div className="bg-gray-800/50 backdrop-blur-xl rounded-xl border border-gray-700 p-6">
                        <h3 className="text-gray-400 text-sm font-medium mb-2">This Month</h3>
                        <p className="text-2xl font-bold text-white">{formatCurrency(dashboard?.monthRevenueCents || 0)}</p>
                    </div>
                    <div className="bg-gray-800/50 backdrop-blur-xl rounded-xl border border-gray-700 p-6 flex items-center justify-between">
                        <div>
                            <h3 className="text-gray-400 text-sm font-medium mb-2">Socket Status</h3>
                            <p className="text-lg font-semibold text-white flex items-center gap-2">
                                <span className={`w-2 h-2 rounded-full ${socket?.connected ? 'bg-green-400' : 'bg-red-400'}`}></span>
                                {socket?.connected ? 'Connected' : 'Disconnected'}
                            </p>
                        </div>
                    </div>
                </div>

                {/* Recent Bookings Table */}
                <div className="bg-gray-800/50 backdrop-blur-xl rounded-xl border border-gray-700 overflow-hidden">
                    <div className="px-6 py-4 border-b border-gray-700">
                        <h2 className="text-lg font-semibold text-white">Recent Bookings</h2>
                    </div>
                    <div className="overflow-x-auto">
                        <table className="w-full">
                            <thead className="bg-gray-700/50">
                                <tr>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">User</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Station</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Vehicle</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Status</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Remaining</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Amount</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Actions</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-700">
                                {bookings.length === 0 ? (
                                    <tr>
                                        <td colSpan={7} className="px-6 py-8 text-center text-gray-400">
                                            No recent bookings
                                        </td>
                                    </tr>
                                ) : (
                                    bookings.map((booking) => (
                                        <tr key={booking.id} className="hover:bg-gray-700/30 transition-colors">
                                            <td className="px-6 py-4">
                                                <div className="text-white font-medium">{booking.user.name}</div>
                                                <div className="text-gray-400 text-sm">{booking.user.email}</div>
                                            </td>
                                            <td className="px-6 py-4">
                                                <div className="text-gray-300">{booking.station.name}</div>
                                                {booking.station.address && (
                                                    <div className="text-gray-500 text-sm truncate max-w-[200px]" title={booking.station.address}>
                                                        📍 {booking.station.address}
                                                    </div>
                                                )}
                                            </td>
                                            <td className="px-6 py-4">
                                                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${booking.vehicle.vehicleType === 'CAR' ? 'bg-blue-500/20 text-blue-400' :
                                                    booking.vehicle.vehicleType === 'SCOOTER' ? 'bg-green-500/20 text-green-400' :
                                                        'bg-purple-500/20 text-purple-400'
                                                    }`}>
                                                    {booking.vehicle.vehicleType}
                                                </span>
                                                <div className="text-gray-400 text-sm mt-1">{booking.vehicle.model}</div>
                                            </td>
                                            <td className="px-6 py-4">
                                                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${booking.status === 'CONFIRMED' ? 'bg-green-500/20 text-green-400' :
                                                    booking.status === 'PENDING' ? 'bg-yellow-500/20 text-yellow-400' :
                                                        booking.status === 'CANCELLED' ? 'bg-red-500/20 text-red-400' :
                                                            'bg-gray-500/20 text-gray-400'
                                                    }`}>
                                                    {booking.status}
                                                </span>
                                            </td>
                                            <td className="px-6 py-4 text-cyan-400 font-mono">
                                                {formatTime(booking.remainingSeconds)}
                                            </td>
                                            <td className="px-6 py-4 text-white">{formatCurrency(booking.amountCents)}</td>
                                            <td className="px-6 py-4">
                                                <button
                                                    onClick={() => handleForceCancel(booking.id)}
                                                    className="px-3 py-1.5 bg-red-500/20 hover:bg-red-500/30 text-red-400 rounded-lg text-sm transition-colors"
                                                >
                                                    Cancel
                                                </button>
                                            </td>
                                        </tr>
                                    ))
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            </main>
        </div>
    );
}

function StatCard({ title, value, icon, color }: { title: string; value: string | number; icon: string; color: string }) {
    const colorClasses = {
        blue: 'from-blue-500 to-blue-600',
        green: 'from-green-500 to-green-600',
        purple: 'from-purple-500 to-purple-600',
        cyan: 'from-cyan-500 to-cyan-600',
    };

    return (
        <div className="bg-gray-800/50 backdrop-blur-xl rounded-xl border border-gray-700 p-6">
            <div className="flex items-center justify-between">
                <div>
                    <p className="text-gray-400 text-sm font-medium">{title}</p>
                    <p className="text-2xl font-bold text-white mt-1">{value}</p>
                </div>
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${colorClasses[color as keyof typeof colorClasses]} flex items-center justify-center text-2xl`}>
                    {icon}
                </div>
            </div>
        </div>
    );
}
