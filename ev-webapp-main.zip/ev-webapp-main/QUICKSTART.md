# Quick Start Guide

## 🚀 Running the Application

### Step 1: Get Google Maps API Key

1. Visit [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project
3. Enable these APIs:
   - Maps JavaScript API
   - Places API
   - Directions API
   - Geocoding API
4. Create an API key
5. Copy the key

### Step 2: Configure Environment

Create `.env.local` in the project root:

```env
NEXT_PUBLIC_GOOGLE_MAPS_API_KEY=your_api_key_here
NEXT_PUBLIC_API_URL=http://localhost:3001
```

### Step 3: Start Backend Server

Open a terminal and run:

```bash
npm run server
```

You should see:
```
🚀 Backend server running on http://localhost:3001
📡 WebSocket server ready
```

### Step 4: Start Frontend

Open another terminal and run:

```bash
npm run dev
```

You should see:
```
▲ Next.js 15.x.x
- Local:        http://localhost:3000
```

### Step 5: Open Browser

Navigate to `http://localhost:3000`

The app will:
1. Request your location (click "Allow")
2. Load Google Maps
3. Fetch charging stations
4. Display stations in sidebar

---

## 🎯 Try These Features

### Book a Charging Slot

1. Click any station in the sidebar
2. Bottom drawer opens with details
3. Select an available connector
4. Click "Book Slot"
5. Watch the 5-minute countdown timer

### Toggle Dark Mode

1. Click the sun/moon icon in bottom-right controls
2. Map and UI smoothly transition to dark theme

### Recenter Map

1. Click the location icon in bottom-right controls
2. Map centers on your current location

---

## 🐛 Troubleshooting

### "Map Loading Error"

**Problem**: Google Maps API key not configured

**Solution**: 
1. Check `.env.local` exists
2. Verify API key is correct
3. Ensure APIs are enabled in Google Cloud Console
4. Restart dev server

### "Failed to connect to server"

**Problem**: Backend server not running

**Solution**:
1. Open terminal
2. Run `npm run server`
3. Verify it shows "Backend server running"

### Stations not loading

**Problem**: Backend not responding

**Solution**:
1. Check backend terminal for errors
2. Verify `http://localhost:3001/health` returns `{"status":"ok"}`
3. Restart backend server

---

## 📁 Project Structure

```
ec-wevapp/
├── app/              # Next.js pages
├── components/       # React components
├── store/           # Zustand state
├── types/           # TypeScript types
├── server/          # Backend API
└── README.md        # Full documentation
```

---

## 🎬 Next Steps

1. **Explore the code** - Check out the components
2. **Customize stations** - Edit `server/services/stationService.js`
3. **Add features** - See README.md for roadmap
4. **Deploy** - Ready for Vercel deployment

---

**Need help?** Check the full [README.md](./README.md) for detailed documentation.
