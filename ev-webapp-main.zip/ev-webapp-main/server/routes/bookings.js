const express = require('express');
const router = express.Router();
const bookingService = require('../services/bookingService');

module.exports = (io) => {
    router.post('/create', async (req, res) => {
        try {
            console.log('[Booking Route] Incoming request body:', JSON.stringify(req.body));
            const booking = await bookingService.createBooking(req.body);
            if (io) {
                // Emit socket event to specific user room if we implemented rooms, 
                // or just broadcast for this demo
                io.emit('booking.created', booking);
            }
            res.json({ success: true, booking });
        } catch (error) {
            console.error('[Booking Route] Error creating booking:');
            console.error('  Message:', error.message);
            console.error('  Code:', error.code);
            console.error('  Meta:', error.meta);
            console.error('  Stack:', error.stack);
            res.status(500).json({ success: false, error: error.message });
        }
    });

    router.post('/confirm', async (req, res) => {
        try {
            const { bookingId } = req.body;
            const success = await bookingService.confirmBooking(bookingId);
            if (success) {
                const updated = await bookingService.getBooking(bookingId);
                if (io) io.emit('booking.updated', updated);
                res.json({ success: true, booking: updated });
            } else {
                res.status(404).json({ success: false, error: 'Booking not found' });
            }
        } catch (error) {
            res.status(500).json({ success: false, error: error.message });
        }
    });

    router.post('/extend', async (req, res) => {
        try {
            const { bookingId, extraMinutes } = req.body;
            console.log(`[Booking Route] Extending booking ${bookingId} by ${extraMinutes} mins`);
            const updated = await bookingService.extendBooking(bookingId, extraMinutes);

            if (io) io.emit('booking.updated', updated);
            res.json({ success: true, booking: updated });
        } catch (error) {
            console.error('[Booking Route] Extend error:', error);
            res.status(500).json({ success: false, error: error.message });
        }
    });

    router.get('/user/:userId', async (req, res) => {
        try {
            const bookings = await bookingService.getUserBookings(req.params.userId);
            res.json(bookings);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    });

    router.get('/:bookingId', async (req, res) => {
        try {
            const booking = await bookingService.getBooking(req.params.bookingId);
            if (booking) res.json(booking);
            else res.status(404).json({ error: 'Not found' });
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    });

    return router;
};
