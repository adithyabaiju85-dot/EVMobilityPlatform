# EV Mobility Platform 🚗⚡

A production-grade, investor-ready web application for EV charging discovery, booking, and intelligent trip planning. Built with Next.js, TypeScript, and Google Maps.

![EV Mobility Platform](https://img.shields.io/badge/Status-Production%20Ready-success)
![Next.js](https://img.shields.io/badge/Next.js-15-black)
![TypeScript](https://img.shields.io/badge/TypeScript-5-blue)
![License](https://img.shields.io/badge/License-MIT-green)

## ✨ Features

### 🗺️ Google Maps-Level Experience
- **Full-screen interactive map** with smooth pan, zoom, rotate, and tilt
- **Custom dark/light themes** with premium styling
- **Marker clustering** for optimal performance
- **Floating controls** for intuitive navigation
- **Real-time geolocation** with auto-detection

### 🔍 Smart Search & Discovery
- **Google Places autocomplete** for instant location search
- **Click-to-drop pins** for destination selection
- **Nearby station discovery** with distance calculation
- **Advanced filtering** by speed, price, availability, and amenities

### 🔌 EV Charging Stations
- **50+ mock stations** across major Indian cities
- **Real-time status** (Available, Busy, Booked, Offline)
- **Detailed station info** with ratings, reviews, and amenities
- **Multiple connector types** (CCS, CHAdeMO, Type2, Tesla)
- **Charging speed indicators** (Slow, Fast, Ultra-Fast)

### 📅 Mock Booking System
- **Time-bound slot booking** with 5-minute expiry
- **Double-booking prevention** with slot locking
- **Real-time status updates** via WebSocket
- **Countdown timers** for active bookings
- **Booking cancellation** with automatic slot release

### 🛣️ Trip Planner (Coming Soon)
- **EV-specific route calculation** with battery optimization
- **Recommended charging stops** along your route
- **Battery level predictions** for each leg
- **Multi-waypoint support** for complex trips

### 🎨 Premium UI/UX
- **Glassmorphism effects** for modern aesthetics
- **Smooth animations** with Framer Motion
- **Responsive design** for all screen sizes
- **Loading skeletons** and empty states
- **Error boundaries** for graceful error handling

---

## 🚀 Quick Start

### Prerequisites

- **Node.js** 18+ and npm
- **Google Maps API Key** (required)

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd ec-wevapp
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Configure environment variables**
   ```bash
   cp .env.local.example .env.local
   ```
   
   Edit `.env.local` and add your Google Maps API key:
   ```env
   NEXT_PUBLIC_GOOGLE_MAPS_API_KEY=your_google_maps_api_key_here
   NEXT_PUBLIC_API_URL=http://localhost:3001
   ```

4. **Start the backend server**
   ```bash
   npm run server
   ```
   Backend will run on `http://localhost:3001`

5. **Start the development server**
   ```bash
   npm run dev
   ```
   Frontend will run on `http://localhost:3000`

6. **Open your browser**
   Navigate to `http://localhost:3000`

---

## 📁 Project Structure

```
ec-wevapp/
├── app/                      # Next.js app directory
│   ├── layout.tsx           # Root layout with fonts
│   ├── page.tsx             # Main application page
│   └── globals.css          # Global styles with Tailwind
├── components/              # React components
│   ├── Layout/
│   │   ├── Navbar.tsx       # Premium navbar
│   │   └── Sidebar.tsx      # Tabbed sidebar
│   ├── Map/
│   │   ├── MapContainer.tsx # Google Maps integration
│   │   └── MapControls.tsx  # Floating map controls
│   └── Stations/
│       ├── StationCard.tsx  # Station list item
│       └── StationDrawer.tsx # Station details drawer
├── store/                   # Zustand state management
│   ├── mapStore.ts          # Map state
│   ├── stationsStore.ts     # Stations & filters
│   ├── bookingsStore.ts     # Booking state
│   └── routeStore.ts        # Route & trip planning
├── types/                   # TypeScript definitions
│   ├── map.ts               # Map types
│   ├── station.ts           # Station types
│   ├── booking.ts           # Booking types
│   └── route.ts             # Route types
├── server/                  # Backend services
│   ├── index.js             # Express server
│   ├── routes/
│   │   ├── bookings.js      # Booking API
│   │   └── stations.js      # Station API
│   └── services/
│       ├── bookingService.js # Mock booking logic
│       └── stationService.js # Mock station data
└── package.json             # Dependencies
```

---

## 🛠️ Tech Stack

### Frontend
- **Next.js 15** - React framework with App Router
- **TypeScript 5** - Type safety
- **Tailwind CSS 3** - Utility-first styling
- **Framer Motion 11** - Smooth animations
- **Zustand 4** - Lightweight state management
- **Google Maps JS API** - Real mapping and directions

### Backend
- **Express 4** - Web server
- **Socket.IO 4** - Real-time WebSocket updates
- **UUID** - Unique booking IDs

---

## 🔑 API Keys Setup

### Google Maps API

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select existing
3. Enable the following APIs:
   - Maps JavaScript API
   - Places API
   - Directions API
   - Geocoding API
4. Create credentials (API Key)
5. Add the key to `.env.local`

**Important**: Restrict your API key in production!

---

## 📊 Available Scripts

```bash
# Development
npm run dev          # Start Next.js dev server
npm run server       # Start backend server

# Production
npm run build        # Build for production
npm start            # Start production server

# Utilities
npm run lint         # Run ESLint
npm run type-check   # TypeScript type checking
```

---

## 🎯 Key Features Explained

### Mock Booking System

The booking system is **demo-safe** and uses in-memory storage:

- **Slot Locking**: Prevents double-booking
- **Expiry Timer**: Bookings auto-expire after 5 minutes
- **Real-time Updates**: WebSocket broadcasts status changes
- **Visual Feedback**: Countdown timers and status badges

### State Management

Uses **Zustand** for clean, performant state:

- `mapStore` - Map viewport, theme, user location
- `stationsStore` - Stations list, filters, selection
- `bookingsStore` - Active bookings, history
- `routeStore` - Routes, directions, trip plans

### Responsive Design

- **Desktop-first** with mobile optimization
- **Glassmorphism** for premium feel
- **Dark mode** support throughout
- **Smooth animations** at 60fps

---

## 🚧 Roadmap

- [ ] **Real Google Directions** integration
- [ ] **Trip Planner** with EV-specific routing
- [ ] **User authentication** and profiles
- [ ] **Payment integration** (Stripe/Razorpay)
- [ ] **Real charging station** API integration
- [ ] **Mobile app** (React Native)
- [ ] **Admin dashboard** for operators
- [ ] **Analytics** and usage tracking

---

## 🤝 Contributing

This is a demo/investor project. For production deployment:

1. Replace mock services with real APIs
2. Add authentication (NextAuth.js, Clerk, etc.)
3. Implement payment processing
4. Add database (PostgreSQL, MongoDB)
5. Deploy to Vercel/AWS/GCP

---

## 📝 License

MIT License - feel free to use for your own projects!

---

## 🙏 Acknowledgments

- **Google Maps** for mapping infrastructure
- **Next.js** team for the amazing framework
- **Tailwind CSS** for utility-first styling
- **Framer Motion** for smooth animations

---

## 📧 Contact

For questions or demo requests, please reach out!

**Built with ❤️ for the future of EV mobility**
