const prisma = require('../lib/prisma');
const { v4: uuidv4 } = require('uuid');

class BookingService {
    async createBooking(request) {
        const { stationId, userId, vehicleModel, slotStart, durationMinutes, connectorId, vehicleId, stationData, travelTimeMinutes } = request;

        console.log(`[BookingService] Request:`, JSON.stringify(request));

        // Validation
        if (!stationId || !userId || !slotStart || !durationMinutes) {
            throw new Error('Missing required booking fields');
        }

        // Timer Logic:
        // slotStart = NOW + Travel Time (when user should arrive)
        // slotEnd = slotStart + 5 min bonus (free time to get to charger)
        // User pays for durationMinutes but timer only shows travel + bonus
        // Extensions add to slotEnd
        const travelBuffer = (travelTimeMinutes || 0) * 60000;
        const bonusMinutes = 5; // Free bonus time
        const requestedStartTime = new Date(slotStart);

        // Start Time = Requested Time + Travel Time
        const startTime = new Date(requestedStartTime.getTime() + travelBuffer);

        // End time = Start time + 5 min bonus (NOT charging duration)
        // This is what the timer counts down to
        const endTime = new Date(startTime.getTime() + bonusMinutes * 60000);

        // Expiration: 15 mins after creation for pending bookings, or tailored to business logic
        const expiresAt = new Date(Date.now() + 15 * 60000);

        // Mock calculations for demo - ₹150/hr rate (15000 paise/hr)
        // Charge only for the requested duration, buffer is free/complimentary
        const amountCents = Math.floor((durationMinutes / 60) * 15000); // ₹150/hr -> 15000 paise
        const energyKwh = (durationMinutes / 60) * 50; // 50kW rate -> kWh

        try {
            // 0. Ensure Station exists in DB (for external Google Places stations)
            let station = await prisma.station.findUnique({ where: { id: stationId } });
            let targetStationId = stationId;

            if (!station) {
                console.log(`[BookingService] Station ${stationId} not found in DB. Creating from external data...`);
                // Station doesn't exist - create it from stationData or with placeholder data
                const newStation = await prisma.station.create({
                    data: {
                        id: stationId, // Use the external ID as the DB ID
                        name: stationData?.name || 'External Charging Station',
                        lat: stationData?.location?.lat || 0,
                        lng: stationData?.location?.lng || 0,
                        address: stationData?.address || 'Unknown Address',
                    }
                });
                targetStationId = newStation.id;
                console.log(`[BookingService] Created station: ${newStation.id}`);

                // Also create a default connector for this station
                await prisma.connector.create({
                    data: {
                        stationId: newStation.id,
                        connectorType: 'Type2',
                        powerKw: 50,
                        slotCount: 2,
                    }
                });
            } else {
                targetStationId = station.id;
            }

            // 1. Resolve Connector
            let targetConnectorId = connectorId;
            if (!targetConnectorId) {
                // Find any connector for this station
                const connector = await prisma.connector.findFirst({ where: { stationId: targetStationId } });
                targetConnectorId = connector ? connector.id : null;
            }

            // 2. Resolve Vehicle
            let targetVehicleId = vehicleId;
            if (!targetVehicleId) {
                if (vehicleModel) {
                    // Try to find a vehicle with this model or create a placeholder
                    const userVehicle = await prisma.vehicle.findFirst({
                        where: { model: vehicleModel }
                    });

                    if (userVehicle) {
                        targetVehicleId = userVehicle.id;
                    } else {
                        // Create a new vehicle for this booking flow
                        const newVehicle = await prisma.vehicle.create({
                            data: {
                                vehicleType: 'CAR',
                                model: vehicleModel,
                            }
                        });
                        targetVehicleId = newVehicle.id;
                    }
                } else {
                    // Fallback to a default vehicle if no model provided
                    const defaultVehicle = await prisma.vehicle.findFirst();
                    if (defaultVehicle) {
                        targetVehicleId = defaultVehicle.id;
                    }
                }
            }

            console.log(`[BookingService] Resolved - Connector: ${targetConnectorId}, Vehicle: ${targetVehicleId}`);

            if (!targetConnectorId) {
                throw new Error(`No connector found for station ${targetStationId}`);
            }
            if (!targetVehicleId) {
                // If we still don't have a vehicle, we can't create a booking
                throw new Error("No vehicle selected or available. Please select a vehicle model.");
            }

            const booking = await prisma.booking.create({
                data: {
                    userId,
                    stationId: targetStationId,
                    connectorId: targetConnectorId,
                    vehicleId: targetVehicleId,
                    vehicleModel: vehicleModel || 'Unknown',
                    slotStart: startTime,
                    slotEnd: endTime,
                    expiresAt: expiresAt,
                    amountCents: amountCents,
                    energyKwh: energyKwh,
                    status: 'PENDING',
                },
                include: {
                    station: true,
                    vehicle: true
                }
            });

            console.log(`[BookingService] Created Booking: ${booking.id}`);
            return booking;
        } catch (error) {
            console.error("[BookingService] Create booking error:", error);
            throw error; // Re-throw to be caught by the route handler
        }
    }

    async confirmBooking(bookingId) {
        try {
            // 1. Fetch booking to get amount
            const booking = await prisma.booking.findUnique({
                where: { id: bookingId }
            });

            if (!booking) {
                throw new Error('Booking not found');
            }

            // 2. Update booking status
            await prisma.booking.update({
                where: { id: bookingId },
                data: { status: 'CONFIRMED' },
            });

            // 3. Create success payment record
            await prisma.payment.create({
                data: {
                    bookingId: bookingId,
                    amountCents: booking.amountCents,
                    status: 'COMPLETED',
                    providerRef: `PAY-${Date.now()}-${Math.floor(Math.random() * 1000)}`
                }
            });

            console.log(`[BookingService] Confirmed Booking ${bookingId} and created Payment`);
            return true;
        } catch (error) {
            console.error("Confirm booking error:", error);
            return false;
        }
    }

    async extendBooking(bookingId, extraMinutes) {
        try {
            const booking = await prisma.booking.findUnique({
                where: { id: bookingId }
            });

            if (!booking) throw new Error('Booking not found');

            const currentEnd = new Date(booking.slotEnd);
            const newEnd = new Date(currentEnd.getTime() + extraMinutes * 60000);

            // Calculate extra cost
            const extraAmountCents = Math.floor((extraMinutes / 60) * 15000);

            // Update booking
            const updatedBooking = await prisma.booking.update({
                where: { id: bookingId },
                data: {
                    slotEnd: newEnd,
                    amountCents: { increment: extraAmountCents },
                    energyKwh: { increment: (extraMinutes / 60) * 50 }
                },
                include: { station: true, vehicle: true }
            });

            // Record additional payment (optional, simplified for now)
            await prisma.payment.create({
                data: {
                    bookingId: bookingId,
                    amountCents: extraAmountCents,
                    status: 'COMPLETED',
                    providerRef: `EXT-${Date.now()}`
                }
            });

            return updatedBooking;
        } catch (error) {
            console.error("Extend booking error:", error);
            throw error;
        }
    }

    async getBooking(bookingId) {
        return prisma.booking.findUnique({
            where: { id: bookingId },
            include: { station: true, vehicle: true, connector: true }
        });
    }

    async getUserBookings(userId) {
        return prisma.booking.findMany({
            where: { userId },
            include: { station: true, vehicle: true },
            orderBy: { slotStart: 'desc' }
        });
    }

    async cancelBooking(bookingId) {
        try {
            await prisma.booking.update({
                where: { id: bookingId },
                data: { status: 'CANCELLED' }
            });
            return true;
        } catch (error) {
            console.error("Cancel booking error:", error);
            return false;
        }
    }
}

module.exports = new BookingService();
