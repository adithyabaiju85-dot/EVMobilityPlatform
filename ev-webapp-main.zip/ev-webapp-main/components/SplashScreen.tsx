import { motion, AnimatePresence } from 'framer-motion';
import Image from 'next/image';

interface SplashScreenProps {
    onComplete: () => void;
}

export default function SplashScreen({ onComplete }: SplashScreenProps) {
    return (
        <motion.div
            className="fixed inset-0 z-[9999] bg-black flex items-center justify-center overflow-hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.8 }}
            onAnimationComplete={(definition) => {
                if (definition === "exit") {
                    onComplete();
                }
            }}
            style={{ perspective: "1000px" }} // Essential for 3D effect
        >
            {/* 3D Scene Container - Responsive Sizing */}
            <div className="relative w-[80vmin] h-[80vmin] flex items-center justify-center transform-style-3d">

                {/* Ring 1 - Outer Slow Rotation (Dark Gold / Bronze) */}
                <motion.div
                    className="absolute border border-[#B8860B]/40 rounded-full w-[70vmin] h-[70vmin] shadow-[0_0_30px_rgba(184,134,11,0.2)]"
                    animate={{
                        rotateX: [0, 360],
                        rotateY: [0, 180],
                        rotateZ: [0, 360]
                    }}
                    transition={{
                        duration: 20, // Slower for premium feel
                        repeat: Infinity,
                        ease: "linear"
                    }}
                    style={{ borderStyle: 'solid', borderWidth: '1px' }}
                />

                {/* Ring 2 - Middle Medium Rotation (Bright Gold) */}
                <motion.div
                    className="absolute border-[2px] border-[#FFD700]/50 rounded-full w-[60vmin] h-[60vmin] shadow-[0_0_20px_rgba(255,215,0,0.3)]"
                    animate={{
                        rotateX: [360, 0],
                        rotateY: [0, 360],
                    }}
                    transition={{
                        duration: 15,
                        repeat: Infinity,
                        ease: "linear"
                    }}
                />

                {/* Ring 3 - Inner Fast Rotation (White Gold / Sparkle) */}
                <motion.div
                    className="absolute border-[1px] border-[#FFF8DC]/70 rounded-full w-[50vmin] h-[50vmin] shadow-[0_0_15px_rgba(255,248,220,0.5)]"
                    animate={{
                        rotateX: [0, 360],
                        rotateZ: [360, 0]
                    }}
                    transition={{
                        duration: 10,
                        repeat: Infinity,
                        ease: "linear"
                    }}
                    style={{ borderTopColor: 'transparent', borderBottomColor: 'transparent' }}
                />

                {/* Central Logo Container - Rotating with the scene - Perfectly Synced */}
                <motion.div
                    className="relative z-20 w-[40vmin] h-[40vmin] flex items-center justify-center transform-style-3d"
                    initial={{ scale: 0.5, opacity: 0, rotateY: 0 }}
                    animate={{
                        scale: 1,
                        opacity: 1,
                        rotateY: 360
                    }}
                    transition={{
                        scale: { duration: 1.5, type: "spring", bounce: 0.4 },
                        opacity: { duration: 1 },
                        rotateY: {
                            duration: 15, // Synced with Ring 2 for harmony
                            repeat: Infinity,
                            ease: "linear"
                        }
                    }}
                >
                    {/* Golden Glowing Backdrop for Logo */}
                    <div className="absolute inset-0 bg-[#FFD700]/10 blur-[50px] rounded-full" />

                    <Image
                        src="/torq-logo-final.png"
                        alt="TORQ EV"
                        fill
                        className="object-contain drop-shadow-[0_0_25px_rgba(212,175,55,0.6)]" // Gold glow
                        style={{
                            filter: 'grayscale(100%) sepia(100%) hue-rotate(5deg) saturate(280%) brightness(110%) contrast(120%)'
                        }}
                        priority
                    />
                </motion.div>
            </div>

            {/* Premium Cinematic Vignette (Deep Black/Gold Hint) */}
            <div
                className="absolute inset-0 z-30 pointer-events-none"
                style={{
                    background: 'radial-gradient(circle at center, transparent 30%, #000 90%)',
                }}
            />
        </motion.div>
    );
}
