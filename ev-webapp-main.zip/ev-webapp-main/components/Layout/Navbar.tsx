'use client';

import { motion } from 'framer-motion';
import Image from 'next/image';
import { useIsMobile } from '@/hooks/useIsMobile';

export default function Navbar() {
    const isMobile = useIsMobile();

    return (
        <motion.nav
            initial={{ y: -100 }}
            animate={{ y: 0 }}
            className={`absolute top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-md border-b-2 border-primary-500 shadow-gold-glow transition-all duration-300 ${isMobile ? 'h-16 px-4 pt-safe' : 'h-20 px-6'
                }`}
        >
            <div className={`flex items-center justify-between h-full w-full`}>
                {/* Logo */}
                <div className="flex items-center gap-3">
                    <div className={`${isMobile ? 'w-10 h-10' : 'w-12 h-12'} relative flex items-center justify-center shadow-gold-glow-lg transition-all rounded-xl overflow-hidden border border-primary-500/50`}>
                        <Image
                            src="/torq-logo-final.jpg"
                            alt="TORQ EV Logo"
                            fill
                            className="object-contain"
                            priority
                        />
                        {/* Shine overlay */}
                        <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/30 to-transparent skew-x-12 animate-shine opacity-50"></div>
                    </div>
                    <div>
                        <h1 className={`${isMobile ? 'text-lg' : 'text-xl'} font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary-300 via-white to-primary-300 drop-shadow-[0_2px_2px_rgba(0,0,0,0.8)] leading-tight tracking-wide`}>
                            TORQ EV
                        </h1>
                        {!isMobile && (
                            <p className="text-xs text-primary-400 font-medium tracking-widest uppercase">
                                Premium Charging
                            </p>
                        )}
                    </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2 md:gap-3">
                    {!isMobile && (
                        <button className="btn-ghost min-h-[44px] min-w-[44px] flex items-center justify-center">
                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    strokeWidth={2}
                                    d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"
                                />
                            </svg>
                        </button>
                    )}

                    <div className="w-8 h-8 md:w-9 md:h-9 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-white font-semibold text-sm cursor-pointer shadow-md border-2 border-white dark:border-gray-800">
                        U
                    </div>
                </div>
            </div>
        </motion.nav>
    );
}
