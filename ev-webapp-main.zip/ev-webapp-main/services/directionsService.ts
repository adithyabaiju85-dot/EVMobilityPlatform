import { LatLng } from '@/types/map';
// Fix import
import { RouteInfo, RouteLeg, RouteStep } from '@/types/route';

export type TravelMode = 'DRIVING' | 'TWO_WHEELER' | 'WALKING';

class DirectionsService {
    private service: google.maps.DirectionsService | null = null;

    initialize() {
        if (!this.service && typeof google !== 'undefined') {
            this.service = new google.maps.DirectionsService();
        }
    }

    async getRouteInfo(origin: LatLng, destination: LatLng, mode: TravelMode = 'DRIVING'): Promise<RouteInfo | null> {
        this.initialize();
        if (!this.service) return null;

        // Map TWO_WHEELER to DRIVING (Google doesn't have native two-wheeler)
        const googleMode = mode === 'TWO_WHEELER' ? 'DRIVING' : mode;

        try {
            const result = await this.service.route({
                origin,
                destination,
                travelMode: google.maps.TravelMode[googleMode as 'DRIVING' | 'WALKING'],
            });

            const route = result.routes[0];
            const legs = route.legs.map(leg => this.mapLeg(leg));
            const leg = route.legs[0];

            // Construct high-fidelity polyline from detailed step paths
            // 'overview_polyline' can be too simplified, causing "straight line" issues on short routes
            let detailedPolyline = route.overview_polyline;

            try {
                if (typeof google !== 'undefined' && google.maps.geometry && google.maps.geometry.encoding) {
                    const fullPath: google.maps.LatLng[] = [];
                    route.legs.forEach(leg => {
                        leg.steps.forEach(step => {
                            // Access detailed path points. 'path' is standard in v3, 'lat_lngs' in some versions.
                            // @ts-ignore
                            const points = step.path || step.lat_lngs;
                            if (points && Array.isArray(points)) {
                                fullPath.push(...points);
                            }
                        });
                    });

                    if (fullPath.length > 0) {
                        detailedPolyline = google.maps.geometry.encoding.encodePath(fullPath);
                    }
                }
            } catch (e) {
                console.warn('⚠️ Failed to encode detailed polyline, falling back to overview:', e);
            }

            // Adjust time for two-wheeler (typically faster in traffic)
            const durationMultiplier = mode === 'TWO_WHEELER' ? 0.8 : 1;

            return {
                distanceMeters: leg.distance?.value || 0,
                durationSeconds: Math.round((leg.duration?.value || 0) * durationMultiplier),
                distanceText: leg.distance?.text || '',
                durationText: mode === 'TWO_WHEELER'
                    ? this.formatDuration(Math.round((leg.duration?.value || 0) * durationMultiplier))
                    : (leg.duration?.text || ''),
                polyline: detailedPolyline,
                legs,
                bounds: route.bounds ? {
                    northeast: { lat: route.bounds.getNorthEast().lat(), lng: route.bounds.getNorthEast().lng() },
                    southwest: { lat: route.bounds.getSouthWest().lat(), lng: route.bounds.getSouthWest().lng() }
                } : undefined,
                summary: route.summary,
                travelMode: mode
            };
        } catch (error) {
            console.error('Directions request failed', error);
            return null;
        }
    }

    private formatDuration(seconds: number): string {
        const mins = Math.floor(seconds / 60);
        if (mins >= 60) {
            const hours = Math.floor(mins / 60);
            const remainMins = mins % 60;
            return `${hours} hr ${remainMins} min`;
        }
        return `${mins} min`;
    }

    private mapLeg(leg: google.maps.DirectionsLeg): RouteLeg {
        return {
            distance: leg.distance?.value || 0,
            duration: leg.duration?.value || 0,
            distanceText: leg.distance?.text || '',
            durationText: leg.duration?.text || '',
            startAddress: leg.start_address,
            endAddress: leg.end_address,
            steps: leg.steps.map(step => this.mapStep(step))
        };
    }

    private mapStep(step: google.maps.DirectionsStep): RouteStep {
        return {
            instruction: step.instructions,
            distance: step.distance?.value || 0,
            duration: step.duration?.value || 0,
            startLocation: { lat: step.start_location.lat(), lng: step.start_location.lng() },
            endLocation: { lat: step.end_location.lat(), lng: step.end_location.lng() },
            maneuver: step.maneuver
        };
    }

    // Helper to calculate spherical distance if API fails or for quick estimates
    getSphericalDistance(origin: LatLng, destination: LatLng): number {
        if (typeof google === 'undefined') return 0;
        return google.maps.geometry.spherical.computeDistanceBetween(
            new google.maps.LatLng(origin.lat, origin.lng),
            new google.maps.LatLng(destination.lat, destination.lng)
        );
    }
}

export const directionsService = new DirectionsService();
