import { LatLng } from './map';

// Charging station types
export type StationStatus = 'available' | 'busy' | 'booked' | 'offline';
export type ConnectorType = 'CCS' | 'CHAdeMO' | 'Type2' | 'Tesla';
export type ChargingSpeed = 'slow' | 'fast' | 'ultra-fast';

export interface Connector {
    id: string;
    type: ConnectorType;
    power: number; // in kW
    available: boolean;
    price: number; // per kWh
}

export interface StationAmenities {
    restroom: boolean;
    restaurant: boolean;
    wifi: boolean;
    parking: boolean;
    shelter: boolean;
}

export interface ChargingStation {
    id: string;
    name: string;
    location: LatLng;
    address: string;
    status: StationStatus;
    connectors: Connector[];
    amenities: StationAmenities;
    rating: number;
    reviews: number;
    distance?: number; // in km
    operatingHours: string;
    operator: string;
    speed: ChargingSpeed;

    // Enriched fields from DirectionsService
    distanceText?: string;
    durationText?: string;
    distanceMeters?: number;
    durationSeconds?: number;
    polyline?: string;

    // Data Source
    source?: 'google' | 'openchargemap' | 'osm' | 'simulated';
}

export interface StationFilters {
    speed?: ChargingSpeed[];
    connectorTypes?: ConnectorType[];
    availability?: boolean;
    maxPrice?: number;
    amenities?: (keyof StationAmenities)[];
}
