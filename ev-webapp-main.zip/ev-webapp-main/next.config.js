module.exports = {
    output: 'standalone',
}
// trigger rebuild
