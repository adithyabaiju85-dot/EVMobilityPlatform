import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useRouteStore, TravelMode } from '@/store/routeStore';
import { useMapStore } from '@/store/mapStore';
import { useStationsStore } from '@/store/stationsStore';
import { directionsService } from '@/services/directionsService';
import { useMobileUIStore } from '@/store/mobileUIStore';
import { useIsMobile } from '@/hooks/useIsMobile';

const TRAVEL_MODES: { mode: TravelMode; icon: string; label: string }[] = [
    { mode: 'DRIVING', icon: '🚗', label: 'Car' },
    { mode: 'TWO_WHEELER', icon: '🛵', label: 'Bike' },
    { mode: 'WALKING', icon: '🚶', label: 'Walk' },
];

export default function RoutePanel() {
    const {
        activeRoute,
        previewRoute,
        isNavigating,
        showModeSelector,
        travelMode,
        destination,
        navigationStartTime,
        clearRoute,
        setTravelMode,
        setPreviewRoute,
        startNavigation,
        setShowModeSelector
    } = useRouteStore();

    const { setDrawerOpen } = useMobileUIStore();
    const { setSelectedStation } = useStationsStore();
    const isMobile = useIsMobile();
    const { userLocation } = useMapStore();
    const [elapsed, setElapsed] = useState(0);
    const [loadingMode, setLoadingMode] = useState<TravelMode | null>(null);

    // Elapsed time counter during navigation
    useEffect(() => {
        if (isNavigating && navigationStartTime) {
            // Close mobile drawer when navigation starts to prevent overlap
            setDrawerOpen(false);
            // Close station details drawer
            setSelectedStation(null);

            const timer = setInterval(() => {
                setElapsed(Math.floor((Date.now() - navigationStartTime) / 1000));
            }, 1000);
            return () => clearInterval(timer);
        }
    }, [isNavigating, navigationStartTime, setDrawerOpen, setSelectedStation]);

    // Fetch route when travel mode changes in mode selector
    const handleModeChange = async (mode: TravelMode) => {
        if (!destination || !userLocation) return;

        setLoadingMode(mode);
        setTravelMode(mode);

        const route = await directionsService.getRouteInfo(
            { lat: userLocation.position.lat, lng: userLocation.position.lng },
            destination.location,
            mode
        );

        if (route) {
            setPreviewRoute(route);
        }
        setLoadingMode(null);
    };

    const handleStartNavigation = () => {
        if (previewRoute) {
            useRouteStore.getState().setActiveRoute(previewRoute);
            startNavigation();
        }
    };

    const formatDistance = (meters: number) => {
        return meters >= 1000 ? `${(meters / 1000).toFixed(1)} km` : `${meters} m`;
    };

    const formatDuration = (seconds: number) => {
        const mins = Math.floor(seconds / 60);
        return mins > 60 ? `${Math.floor(mins / 60)}h ${mins % 60}m` : `${mins} min`;
    };

    const formatElapsed = (seconds: number) => {
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    };

    const routeToShow = isNavigating ? activeRoute : previewRoute;
    const firstLeg = routeToShow?.legs?.[0];
    const steps = firstLeg?.steps || [];

    // Travel mode selector view
    if (showModeSelector && destination) {
        return (
            <motion.div
                initial={{ y: 100, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                exit={{ y: 100, opacity: 0 }}
                className="absolute bottom-6 left-6 right-6 md:left-auto md:right-6 md:w-96 z-50"
            >
                <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-2xl overflow-hidden">
                    {/* Header */}
                    <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-4 text-white">
                        <div className="flex items-center justify-between">
                            <div>
                                <h3 className="font-bold text-lg">Navigate to</h3>
                                <p className="text-white/80 text-sm truncate max-w-[200px]">{destination.name}</p>
                            </div>
                            <button
                                onClick={() => {
                                    setShowModeSelector(false);
                                    clearRoute();
                                }}
                                className="p-2 hover:bg-white/20 rounded-full transition"
                            >
                                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                </svg>
                            </button>
                        </div>
                    </div>

                    {/* Travel Mode Selector */}
                    <div className="p-4">
                        <div className="flex gap-2 mb-4">
                            {TRAVEL_MODES.map(({ mode, icon, label }) => (
                                <button
                                    key={mode}
                                    onClick={() => handleModeChange(mode)}
                                    className={`flex-1 py-3 px-4 rounded-xl font-medium transition-all flex flex-col items-center gap-1 ${travelMode === mode
                                        ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg shadow-blue-500/30'
                                        : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
                                        }`}
                                >
                                    <span className="text-2xl">{loadingMode === mode ? '⏳' : icon}</span>
                                    <span className="text-xs">{label}</span>
                                </button>
                            ))}
                        </div>

                        {/* Route Preview */}
                        {previewRoute ? (
                            <div className="bg-gray-50 dark:bg-gray-800 rounded-xl p-4 mb-4">
                                <div className="flex items-center justify-between">
                                    <div>
                                        <div className="text-3xl font-bold text-gray-900 dark:text-white">
                                            {formatDuration(previewRoute.durationSeconds)}
                                        </div>
                                        <div className="text-sm text-gray-500">
                                            {formatDistance(previewRoute.distanceMeters)} • via {previewRoute.summary || 'fastest route'}
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <div className="text-sm text-gray-500">Arrive by</div>
                                        <div className="font-bold text-gray-900 dark:text-white">
                                            {new Date(Date.now() + previewRoute.durationSeconds * 1000).toLocaleTimeString([], {
                                                hour: '2-digit',
                                                minute: '2-digit'
                                            })}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ) : (
                            <div className="bg-gray-50 dark:bg-gray-800 rounded-xl p-4 mb-4 text-center">
                                <div className="animate-pulse text-gray-400">Loading route...</div>
                            </div>
                        )}

                        {/* Start Button */}
                        <motion.button
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={handleStartNavigation}
                            disabled={!previewRoute}
                            className="w-full py-4 bg-gradient-to-r from-green-500 to-emerald-500 text-white font-bold rounded-xl shadow-lg shadow-green-500/30 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 text-lg"
                        >
                            <span>🚀</span> Start Navigation
                        </motion.button>
                    </div>
                </div>
            </motion.div>
        );
    }

    // Active navigation view
    if (!activeRoute || !isNavigating) return null;

    const getModeIcon = () => {
        switch (activeRoute.travelMode) {
            case 'TWO_WHEELER': return '🛵';
            case 'WALKING': return '🚶';
            default: return '🚗';
        }
    };

    return (
        <motion.div
            initial={{ x: -100, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: -100, opacity: 0 }}
            className={`${isMobile ? 'fixed top-14 left-0 right-0 px-4 w-full max-h-[50vh]' : 'absolute top-20 left-6 w-80 max-h-[60vh]'} z-50`}
        >
            <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-full">
                {/* Navigation Header */}
                <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 p-4 text-white">
                    <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                            <span className="text-2xl">{getModeIcon()}</span>
                            <span className="bg-white/20 px-2 py-0.5 rounded-full text-xs font-bold animate-pulse">
                                LIVE
                            </span>
                        </div>
                        <div className="text-right">
                            <div className="text-xs opacity-70">Elapsed</div>
                            <div className="font-mono font-bold">{formatElapsed(elapsed)}</div>
                        </div>
                    </div>

                    <div className="flex items-baseline gap-3">
                        <span className="text-4xl font-bold">{formatDuration(activeRoute.durationSeconds)}</span>
                        <span className="opacity-80">{formatDistance(activeRoute.distanceMeters)}</span>
                    </div>

                    <div className="mt-2 flex items-center gap-2 text-sm">
                        <span className="opacity-70">Arrive by</span>
                        <span className="font-bold">
                            {new Date(Date.now() + activeRoute.durationSeconds * 1000).toLocaleTimeString([], {
                                hour: '2-digit',
                                minute: '2-digit'
                            })}
                        </span>
                    </div>
                </div>

                {/* End Navigation Button - directly after header */}
                <div className="p-4 bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700">
                    <button
                        onClick={clearRoute}
                        className="w-full py-3 bg-gradient-to-r from-red-500 to-rose-500 text-white font-bold rounded-xl shadow-lg hover:shadow-xl transition flex items-center justify-center gap-2"
                    >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                        End Navigation
                    </button>
                </div>
            </div>
        </motion.div>
    );
}
