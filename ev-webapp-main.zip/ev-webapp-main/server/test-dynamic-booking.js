const bookingService = require('./services/bookingService');
const prisma = require('./lib/prisma');

async function testDynamicBooking() {
    console.log('--- Starting Dynamic Booking Test ---');

    // Mock Request

    // Create or find a user
    const userEmail = 'test@example.com';
    let user = await prisma.user.findUnique({ where: { email: userEmail } });
    if (!user) {
        user = await prisma.user.create({
            data: {
                name: 'Test User',
                email: userEmail,
                passwordHash: 'hash',
            }
        });
        console.log('Created test user:', user.id);
    }
    const userId = user.id;
    const stationId = 'test-station-1';

    // 1. Create Booking with Travel Time
    // Travel Time: 20 mins
    // Duration: 30 mins
    // Expected Start: Now + 20m
    // Expected End: Now + 20m + 30m + 5m (buffer) = Now + 55m

    const request = {
        stationId,
        userId,
        slotStart: new Date().toISOString(),
        durationMinutes: 30,
        travelTimeMinutes: 20,
        vehicleModel: 'Tesla Model 3',
        stationData: { name: 'Test Station' }
    };

    console.log('Creating booking with 20min travel time and 30min duration...');
    const booking = await bookingService.createBooking(request);

    const now = Date.now();
    const startTime = new Date(booking.slotStart).getTime();
    const endTime = new Date(booking.slotEnd).getTime();

    const expectedStartDiff = (startTime - now) / 60000;
    const totalDuration = (endTime - startTime) / 60000;

    console.log(`Booking ID: ${booking.id}`);
    console.log(`Start Time Delay (approx): ${expectedStartDiff.toFixed(1)} mins (Expected ~20)`);
    console.log(`Total Duration: ${totalDuration.toFixed(1)} mins (Expected 30 + 5 = 35)`);

    if (Math.abs(expectedStartDiff - 20) > 1) console.error('FAIL: Start time incorrect');
    else console.log('PASS: Start time correct');

    if (Math.abs(totalDuration - 35) > 1) console.error('FAIL: Duration with buffer incorrect');
    else console.log('PASS: Duration with buffer correct');

    // 2. Extend Booking
    console.log('\nExtending booking by 15 mins...');
    const extended = await bookingService.extendBooking(booking.id, 15);

    const extendedEnd = new Date(extended.slotEnd).getTime();
    const extensionDiff = (extendedEnd - endTime) / 60000;

    console.log(`Extended by: ${extensionDiff.toFixed(1)} mins (Expected 15)`);

    if (Math.abs(extensionDiff - 15) > 1) console.error('FAIL: Extension incorrect');
    else console.log('PASS: Extension correct');

    // Cleanup
    try {
        if (booking) await bookingService.cancelBooking(booking.id);
    } catch (e) { }
    console.log('\nTest Completed');
    process.exit(0);
}

testDynamicBooking().catch(e => {
    console.error('TEST FAILED');
    console.error(e);
    if (e.meta) console.error('Meta:', e.meta);
    process.exit(1);
});
