import { LatLng } from '@/types/map';
import { RouteInfo, ChargingStop, RouteLeg, TripPlanRequest, TripPlanResult } from '@/types/route';
import { ChargingStation } from '@/types/station';
import { directionsService } from './directionsService';

// Constants for EV routing
const SAFETY_BUFFER = 0.15; // 15% safety margin
const DEFAULT_CHARGER_POWER_KW = 50; // Default fast charger power
const BATTERY_CAPACITY_KWH = 60; // Typical EV battery (can be made configurable)

export class TripPlannerService {

    /**
     * Main entry point for planning an EV trip
     */
    async planEVTrip(request: TripPlanRequest): Promise<TripPlanResult> {
        const { origin, destination, batteryPercent, vehicleRangeKm } = request;

        // Validate inputs
        if (batteryPercent < 5) return { success: false, error: 'Battery too low to start trip. Please charge first.' };
        if (vehicleRangeKm < 50) return { success: false, error: 'Vehicle range must be at least 50 km.' };

        try {
            // Step 1: Geocode string locations if needed
            const originLatLng = await this.resolveLocation(origin);
            const destLatLng = await this.resolveLocation(destination);

            if (!originLatLng) return { success: false, error: `Could not find "${origin}". Try being more specific.` };
            if (!destLatLng) return { success: false, error: `Could not find "${destination}". Try being more specific.` };

            // Step 2: Get full route from Directions API
            const fullRoute = await directionsService.getRouteInfo(originLatLng, destLatLng, 'DRIVING');
            if (!fullRoute) {
                return { success: false, error: 'Could not calculate route. Please check locations.' };
            }

            const totalDistanceKm = fullRoute.distanceMeters / 1000;
            console.log(`🛣️ Trip: ${totalDistanceKm.toFixed(1)} km total`);

            // Step 3: Calculate usable range
            const currentRangeKm = vehicleRangeKm * (batteryPercent / 100);
            const usableRangeKm = currentRangeKm * (1 - SAFETY_BUFFER);

            console.log(`🔋 Battery: ${batteryPercent}%, Range: ${currentRangeKm.toFixed(0)} km, Usable: ${usableRangeKm.toFixed(0)} km`);

            // Step 4: Check if charging needed
            if (usableRangeKm >= totalDistanceKm) {
                console.log('✅ Trip within range - no charging stops needed');
                return {
                    success: true,
                    tripPlan: {
                        route: fullRoute,
                        chargingStops: [],
                        totalDistance: totalDistanceKm,
                        totalDuration: fullRoute.durationSeconds,
                        totalChargingTime: 0,
                        feasible: true,
                        warnings: []
                    }
                };
            }

            // Step 5: We need charging stops
            console.log('⚡ Charging stops required - calculating optimal route...');
            const chargingStops = await this.calculateChargingStops(
                originLatLng,
                destLatLng,
                fullRoute,
                batteryPercent,
                vehicleRangeKm
            );

            if (!chargingStops || chargingStops.length === 0) {
                return {
                    success: false,
                    error: 'Could not find suitable charging stations along your route.'
                };
            }

            // Step 6: Calculate total charging time
            const totalChargingTime = chargingStops.reduce((sum, stop) => sum + stop.chargingTime, 0);

            return {
                success: true,
                tripPlan: {
                    route: fullRoute,
                    chargingStops,
                    totalDistance: totalDistanceKm,
                    totalDuration: fullRoute.durationSeconds + (totalChargingTime * 60),
                    totalChargingTime,
                    feasible: true,
                    warnings: chargingStops.length > 3
                        ? ['Multiple charging stops required.']
                        : []
                }
            };

        } catch (error) {
            console.error('Trip planning failed:', error);
            return { success: false, error: 'An error occurred while planning your trip.' };
        }
    }

    /**
     * Core algorithm: Calculate optimal charging stops along route
     */
    private async calculateChargingStops(
        origin: LatLng,
        destination: LatLng,
        route: RouteInfo,
        batteryPercent: number,
        vehicleRangeKm: number
    ): Promise<ChargingStop[]> {
        const chargingStops: ChargingStop[] = [];
        const totalDistanceKm = route.distanceMeters / 1000;

        let currentBatteryPercent = batteryPercent;
        let distanceTraveledKm = 0;

        // Get all stations along the route corridor
        const routeStations = await this.findStationsAlongRoute(route, origin);
        console.log(`📍 Found ${routeStations.length} charging stations along route`);

        if (routeStations.length === 0) return [];

        let loopSafety = 0;
        while (distanceTraveledKm < totalDistanceKm) {
            loopSafety++;
            if (loopSafety > 20) break;

            const remainingDistanceKm = totalDistanceKm - distanceTraveledKm;
            const currentRangeKm = vehicleRangeKm * (currentBatteryPercent / 100);
            const usableRangeKm = currentRangeKm * (1 - SAFETY_BUFFER);

            if (usableRangeKm >= remainingDistanceKm) break;

            // Find optimal station
            let optimalStation = this.findOptimalChargingStation(
                routeStations,
                distanceTraveledKm,
                usableRangeKm,
                remainingDistanceKm
            );

            if (!optimalStation) {
                console.warn('⚠️ No cached station found in range. Attempting rescue search...');

                // Rescue Strategy: Search explicitly at the limit of our range
                const rescueDistKm = distanceTraveledKm + (usableRangeKm * 0.9); // search at 90% of range
                const rescuePoint = this.findPointAtDistance(route, rescueDistKm);

                if (rescuePoint) {
                    console.log('SEARCHING RESCUE POINT:', rescuePoint);
                    try {
                        const { fetchNearbyStations } = await import('./stationsService');
                        const rescueStations = await fetchNearbyStations(rescuePoint, 50000); // Wide search

                        if (rescueStations && rescueStations.length > 0) {
                            console.log(`✅ Rescue found ${rescueStations.length} stations!`);
                            // Add to our pool with approximate route distance (rescueDistKm)
                            const newStations = rescueStations.map(s => ({
                                station: s,
                                distanceFromStartKm: rescueDistKm, // It's near the rescue point
                                detourKm: this.calculateDistanceKm(rescuePoint, s.location) // Detour from route point
                            }));
                            routeStations.push(...newStations);

                            // Retry finding optimal
                            optimalStation = this.findOptimalChargingStation(
                                routeStations,
                                distanceTraveledKm,
                                usableRangeKm,
                                remainingDistanceKm
                            );
                        }
                    } catch (err) {
                        console.error('Rescue search failed:', err);
                    }
                }

                if (!optimalStation) {
                    console.error('❌ No reachable charging station found even after rescue.');
                    break;
                }
            }

            // Calculations
            const distanceToStationKm = optimalStation.distanceFromStartKm - distanceTraveledKm;
            const batteryUsedPercent = (distanceToStationKm / vehicleRangeKm) * 100;
            const arrivalBatteryPercent = Math.max(0, currentBatteryPercent - batteryUsedPercent);
            const remainingAfterStation = totalDistanceKm - optimalStation.distanceFromStartKm;

            const nextStopDistance = this.findDistanceToNextStop(
                routeStations,
                optimalStation.distanceFromStartKm,
                remainingAfterStation
            );

            const requiredRangeKm = Math.min(nextStopDistance * 1.3, remainingAfterStation * 1.2);
            const requiredBatteryPercent = Math.min(80, (requiredRangeKm / vehicleRangeKm) * 100);
            const targetBatteryPercent = Math.max(requiredBatteryPercent, 60);

            const chargeNeededPercent = targetBatteryPercent - arrivalBatteryPercent;
            const chargeNeededKWh = (chargeNeededPercent / 100) * BATTERY_CAPACITY_KWH;
            const chargerPower = optimalStation.station.connectors?.[0]?.power || DEFAULT_CHARGER_POWER_KW;
            const chargingTimeMinutes = Math.max(10, Math.ceil((chargeNeededKWh / chargerPower) * 60));

            chargingStops.push({
                stationId: optimalStation.station.id,
                name: optimalStation.station.name,
                address: optimalStation.station.address,
                location: optimalStation.station.location,
                arrivalBattery: Math.round(arrivalBatteryPercent),
                departureBattery: Math.round(targetBatteryPercent),
                chargingTime: chargingTimeMinutes,
                reason: `Charge to ${Math.round(targetBatteryPercent)}% to reach ${nextStopDistance < remainingAfterStation ? 'next stop' : 'destination'}`,
                stationData: optimalStation.station
            });

            distanceTraveledKm = optimalStation.distanceFromStartKm;
            currentBatteryPercent = targetBatteryPercent;
        }

        return chargingStops;
    }

    private findOptimalChargingStation(
        stations: StationWithDistance[],
        currentDistanceKm: number,
        usableRangeKm: number,
        remainingToDestinationKm: number
    ): StationWithDistance | null {
        const reachableStations = stations.filter(s => {
            const distanceToStation = s.distanceFromStartKm - currentDistanceKm;
            return distanceToStation > 0 && distanceToStation <= usableRangeKm;
        });

        if (reachableStations.length === 0) return null;

        // Select best station: Furthest progress along route MINUS penalty for detour
        // Score = Progress - (Detour * Penalty)
        // We want to maximize Score.
        return reachableStations.sort((a, b) => {
            const progressA = a.distanceFromStartKm;
            const progressB = b.distanceFromStartKm;

            const detourA = a.detourKm || 0;
            const detourB = b.detourKm || 0;

            // Heavy penalty for detour to prioritize "failed to location" (faster/direct)
            const scoreA = progressA - (detourA * 3);
            const scoreB = progressB - (detourB * 3);

            return scoreB - scoreA; // Descending score
        })[0];
    }

    private findDistanceToNextStop(
        stations: StationWithDistance[],
        currentDistanceKm: number,
        remainingRouteKm: number
    ): number {
        const nextStation = stations.find(s => s.distanceFromStartKm > currentDistanceKm + 50);
        if (nextStation) {
            return nextStation.distanceFromStartKm - currentDistanceKm;
        }
        return remainingRouteKm;
    }

    private async findStationsAlongRoute(route: RouteInfo, startLocation: LatLng): Promise<StationWithDistance[]> {
        if (!route.legs || route.legs.length === 0) return [];

        try {
            const { placesEVService } = await import('./placesEVService');

            // Structure: { location: LatLng, routeDistKm: number }
            const searchPoints: { location: LatLng, routeDistKm: number }[] = [];

            // 1. Always add Start Location
            searchPoints.push({ location: startLocation, routeDistKm: 0 });

            // 2. Iterate through legs and steps to sample points every ~100km
            let accumulatedDistanceMeters = 0;
            const SAMPLE_INTERVAL_METERS = 100000; // 100 km
            let nextSampleThreshold = SAMPLE_INTERVAL_METERS;

            for (const leg of route.legs) {
                if (!leg.steps) continue;

                for (const step of leg.steps) {
                    accumulatedDistanceMeters += step.distance;

                    // If we've crossed the threshold, add this step's end location
                    if (accumulatedDistanceMeters >= nextSampleThreshold) {
                        searchPoints.push({
                            location: step.endLocation,
                            routeDistKm: accumulatedDistanceMeters / 1000
                        });
                        nextSampleThreshold += SAMPLE_INTERVAL_METERS;
                    }
                }
            }

            // 3. Always add Destination
            const lastLeg = route.legs[route.legs.length - 1];
            if (lastLeg.steps && lastLeg.steps.length > 0) {
                const lastStep = lastLeg.steps[lastLeg.steps.length - 1];
                searchPoints.push({
                    location: lastStep.endLocation,
                    routeDistKm: route.distanceMeters / 1000
                });
            }

            console.log(`📍 Sampling ${searchPoints.length} points along route for stations...`);

            let allStations: StationWithDistance[] = [];

            // Helper for batched execution
            const processBatch = async (points: typeof searchPoints) => {
                const promises = points.map(async (point) => {
                    try {
                        // Search radius 50km
                        // DIRECT CALL OPTIMIZATION: Use placesEVService directly to avoid Directions API overhead
                        const found = await placesEVService.fetchRealChargingStations(point.location, 50000);
                        if (found) {
                            return found.map(s => {
                                const detour = this.calculateDistanceKm(point.location, s.location);
                                return {
                                    station: s,
                                    distanceFromStartKm: point.routeDistKm,
                                    detourKm: detour
                                };
                            });
                        }
                    } catch (err) {
                        console.warn('Failed to fetch stations for point', point, err);
                    }
                    return [];
                });
                return Promise.all(promises);
            };

            // Execute in batches of 5 to avoid API rate limits
            const BATCH_SIZE = 5;
            for (let i = 0; i < searchPoints.length; i += BATCH_SIZE) {
                const batch = searchPoints.slice(i, i + BATCH_SIZE);
                console.log(`🔄 Processing batch ${Math.floor(i / BATCH_SIZE) + 1}/${Math.ceil(searchPoints.length / BATCH_SIZE)}...`);
                const results = await processBatch(batch);
                results.forEach(res => {
                    if (res) allStations.push(...res);
                });
            }

            // Deduplicate stations by ID, keeping the one with minimal detour
            const uniqueStationsMap = new Map<string, StationWithDistance>();
            for (const s of allStations) {
                const existing = uniqueStationsMap.get(s.station.id);
                if (!existing || (s.detourKm! < existing.detourKm!)) {
                    uniqueStationsMap.set(s.station.id, s);
                }
            }

            const uniqueStations = Array.from(uniqueStationsMap.values());

            console.log(`🔍 [TripPlanner] Search Points: ${searchPoints.length}, Found: ${uniqueStations.length} unique stations`);

            return uniqueStations.sort((a, b) => a.distanceFromStartKm - b.distanceFromStartKm);

        } catch (error) {
            console.error('Failed to fetch stations along route:', error);
            return [];
        }
    }

    private async resolveLocation(location: LatLng | string): Promise<LatLng | null> {
        if (typeof location !== 'string') return location;
        if (!location || location.trim() === '') return null;
        if (location.toLowerCase().includes('location')) return null;

        try {
            if (typeof google === 'undefined' || !google.maps) return null;
            const geocoder = new google.maps.Geocoder();
            const result = await geocoder.geocode({ address: location });

            if (result.results && result.results.length > 0) {
                const loc = result.results[0].geometry.location;
                return { lat: loc.lat(), lng: loc.lng() };
            }
            return null;
        } catch (error) {
            console.error('Geocoding failed:', error);
            return null;
        }
    }

    private calculateDistanceKm(point1: LatLng, point2: LatLng): number {
        // Robust handling for LatLng objects (function vs property)
        const getLat = (p: any) => typeof p.lat === 'function' ? p.lat() : p.lat;
        const getLng = (p: any) => typeof p.lng === 'function' ? p.lng() : p.lng;

        const p1Lat = getLat(point1);
        const p1Lng = getLng(point1);
        const p2Lat = getLat(point2);
        const p2Lng = getLng(point2);

        const R = 6371;
        const dLat = (p2Lat - p1Lat) * Math.PI / 180;
        const dLon = (p2Lng - p1Lng) * Math.PI / 180;
        const a =
            Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(p1Lat * Math.PI / 180) * Math.cos(p2Lat * Math.PI / 180) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
    }

    private findPointAtDistance(route: RouteInfo, targetDistanceKm: number): LatLng | null {
        if (!route.legs) return null;

        let currentDist = 0;
        const targetMeters = targetDistanceKm * 1000;

        for (const leg of route.legs) {
            if (!leg.steps) continue;
            for (const step of leg.steps) {
                if (currentDist + step.distance >= targetMeters) {
                    return step.endLocation;
                }
                currentDist += step.distance;
            }
        }
        return null;
    }
}

interface StationWithDistance {
    station: ChargingStation;
    distanceFromStartKm: number;
    detourKm?: number;
}

export const tripPlannerService = new TripPlannerService();
