const express = require('express');
const router = express.Router();
const externalStationsService = require('../services/externalStationsService');

router.get('/', async (req, res) => {
    try {
        const { lat, lng, radius, north, south, east, west } = req.query;

        if (!lat || !lng) {
            return res.status(400).json({ error: 'Missing required parameters: lat, lng' });
        }

        // Parse params
        const userLat = parseFloat(lat);
        const userLng = parseFloat(lng);
        const searchRadius = radius ? parseInt(radius) : 5000;

        let bounds = null;
        if (north && south && east && west) {
            bounds = {
                north: parseFloat(north),
                south: parseFloat(south),
                east: parseFloat(east),
                west: parseFloat(west)
            };
        }

        const data = await externalStationsService.fetchStations({
            lat: userLat,
            lng: userLng,
            radius: searchRadius,
            bounds
        });

        res.json(data);

    } catch (error) {
        console.error('API Error:', error);
        res.status(500).json({
            error: 'Internal Server Error',
            details: error.message
        });
    }
});

module.exports = router;
