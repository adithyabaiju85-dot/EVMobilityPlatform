export default function SkeletonStationCard() {
    return (
        <div className="p-4 bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-100 dark:border-gray-700 animate-pulse">
            <div className="flex justify-between items-start mb-2">
                <div className="h-6 w-2/3 bg-gray-200 dark:bg-gray-700 rounded mb-2"></div>
                <div className="h-5 w-12 bg-gray-200 dark:bg-gray-700 rounded"></div>
            </div>
            <div className="h-4 w-3/4 bg-gray-200 dark:bg-gray-700 rounded mb-4"></div>

            <div className="flex gap-2 mb-3">
                <div className="h-6 w-16 bg-gray-200 dark:bg-gray-700 rounded-full"></div>
                <div className="h-6 w-16 bg-gray-200 dark:bg-gray-700 rounded-full"></div>
            </div>

            <div className="flex justify-between items-center mt-2">
                <div className="h-4 w-1/3 bg-gray-200 dark:bg-gray-700 rounded"></div>
                <div className="h-8 w-24 bg-gray-300 dark:bg-gray-600 rounded"></div>
            </div>
        </div>
    );
}
