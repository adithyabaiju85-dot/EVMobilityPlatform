'use client';

import { useEffect, useState, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

interface Booking {
    id: string;
    user: { name: string; email: string };
    station: { name: string; address?: string };
    vehicle: { vehicleType: string; model: string };
    status: string;
    slotStart: string;
    slotEnd: string;
    amountCents: number;
    createdAt: string;
}

interface Pagination {
    page: number;
    size: number;
    total: number;
    totalPages: number;
}

export default function BookingHistoryPage() {
    const router = useRouter();
    const [loading, setLoading] = useState(true);
    const [bookings, setBookings] = useState<Booking[]>([]);
    const [pagination, setPagination] = useState<Pagination | null>(null);
    const [filterStatus, setFilterStatus] = useState<string>('ALL');
    const [currentPage, setCurrentPage] = useState(1);
    const [user, setUser] = useState<any>(null);

    const fetchBookings = useCallback(async (token: string, page: number, status: string) => {
        try {
            setLoading(true);
            let url = `http://localhost:3001/api/admin/bookings?page=${page}&size=20`;
            if (status !== 'ALL') {
                url += `&status=${status}`;
            }

            const res = await fetch(url, {
                headers: { Authorization: `Bearer ${token}` },
            });
            if (!res.ok) throw new Error('Failed to fetch bookings');
            const data = await res.json();
            setBookings(data.bookings);
            setPagination(data.pagination);
        } catch (err) {
            console.error('Fetch error:', err);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        const token = localStorage.getItem('adminToken');
        const userStr = localStorage.getItem('adminUser');

        if (!token || !userStr) {
            router.push('/admin/login');
            return;
        }

        try {
            setUser(JSON.parse(userStr));
        } catch {
            router.push('/admin/login');
            return;
        }

        fetchBookings(token, currentPage, filterStatus);
    }, [router, currentPage, filterStatus, fetchBookings]);

    const handleLogout = () => {
        localStorage.removeItem('adminToken');
        localStorage.removeItem('adminUser');
        router.push('/admin/login');
    };

    const handleForceCancel = async (bookingId: string) => {
        if (!confirm('Are you sure you want to force cancel this booking? This action cannot be undone.')) return;

        const token = localStorage.getItem('adminToken');
        if (!token) return;

        try {
            const res = await fetch('http://localhost:3001/api/admin/booking/force-cancel', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify({ bookingId }),
            });

            if (!res.ok) throw new Error('Failed to cancel');
            // Refresh current view
            fetchBookings(token, currentPage, filterStatus);
        } catch (err: any) {
            alert(err.message);
        }
    };

    const formatCurrency = (cents: number) => {
        return `₹${(cents / 100).toLocaleString('en-IN')}`;
    };

    const formatDate = (dateStr: string) => {
        return new Date(dateStr).toLocaleString('en-IN', {
            day: '2-digit',
            month: 'short',
            hour: '2-digit',
            minute: '2-digit',
        });
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
            {/* Header */}
            <header className="bg-gray-800/50 backdrop-blur-xl border-b border-gray-700 sticky top-0 z-50">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <Link href="/admin" className="p-2 hover:bg-gray-700 rounded-full transition-colors">
                            <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                            </svg>
                        </Link>
                        <div>
                            <h1 className="text-xl font-bold text-white">Booking History</h1>
                            <p className="text-sm text-gray-400">Manage all system bookings</p>
                        </div>
                    </div>
                    <div className="flex items-center gap-4">
                        <span className="text-gray-400 text-sm hidden sm:block">Admin: {user?.name}</span>
                        <button
                            onClick={handleLogout}
                            className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-gray-300 rounded-lg transition-colors"
                        >
                            Logout
                        </button>
                    </div>
                </div>
            </header>

            <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                {/* Filters */}
                <div className="flex flex-wrap items-center gap-4 mb-6">
                    {['ALL', 'CONFIRMED', 'COMPLETED', 'CANCELLED', 'EXPIRED'].map((status) => (
                        <button
                            key={status}
                            onClick={() => {
                                setFilterStatus(status);
                                setCurrentPage(1); // Reset to page 1 on filter change
                            }}
                            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${filterStatus === status
                                    ? 'bg-blue-600 text-white'
                                    : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                                }`}
                        >
                            {status === 'ALL' ? 'All Bookings' : status.charAt(0) + status.slice(1).toLowerCase()}
                        </button>
                    ))}
                </div>

                {/* Table */}
                <div className="bg-gray-800/50 backdrop-blur-xl rounded-xl border border-gray-700 overflow-hidden mb-6">
                    <div className="overflow-x-auto">
                        <table className="w-full">
                            <thead className="bg-gray-700/50">
                                <tr>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Date</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">User</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Station</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Vehicle</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Status</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Amount</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Actions</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-700">
                                {loading ? (
                                    <tr>
                                        <td colSpan={7} className="px-6 py-8 text-center text-gray-400">
                                            Loading...
                                        </td>
                                    </tr>
                                ) : bookings.length === 0 ? (
                                    <tr>
                                        <td colSpan={7} className="px-6 py-8 text-center text-gray-400">
                                            No bookings found
                                        </td>
                                    </tr>
                                ) : (
                                    bookings.map((booking) => (
                                        <tr key={booking.id} className="hover:bg-gray-700/30 transition-colors">
                                            <td className="px-6 py-4 text-gray-300 text-sm">
                                                {formatDate(booking.createdAt)}
                                            </td>
                                            <td className="px-6 py-4">
                                                <div className="text-white font-medium">{booking.user.name}</div>
                                                <div className="text-gray-400 text-sm">{booking.user.email}</div>
                                            </td>
                                            <td className="px-6 py-4">
                                                <div className="text-gray-300">{booking.station.name}</div>
                                                {booking.station.address && (
                                                    <div className="text-gray-500 text-sm truncate max-w-[200px]" title={booking.station.address}>
                                                        📍 {booking.station.address}
                                                    </div>
                                                )}
                                            </td>
                                            <td className="px-6 py-4">
                                                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${booking.vehicle.vehicleType === 'CAR' ? 'bg-blue-500/20 text-blue-400' :
                                                        booking.vehicle.vehicleType === 'SCOOTER' ? 'bg-green-500/20 text-green-400' :
                                                            'bg-purple-500/20 text-purple-400'
                                                    }`}>
                                                    {booking.vehicle.vehicleType}
                                                </span>
                                                <div className="text-gray-400 text-sm mt-1">{booking.vehicle.model}</div>
                                            </td>
                                            <td className="px-6 py-4">
                                                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${booking.status === 'CONFIRMED' ? 'bg-green-500/20 text-green-400' :
                                                        booking.status === 'PENDING' ? 'bg-yellow-500/20 text-yellow-400' :
                                                            booking.status === 'CANCELLED' ? 'bg-red-500/20 text-red-400' :
                                                                'bg-gray-500/20 text-gray-400'
                                                    }`}>
                                                    {booking.status}
                                                </span>
                                            </td>
                                            <td className="px-6 py-4 text-white font-mono">
                                                {formatCurrency(booking.amountCents)}
                                            </td>
                                            <td className="px-6 py-4">
                                                {(booking.status === 'CONFIRMED' || booking.status === 'PENDING') && (
                                                    <button
                                                        onClick={() => handleForceCancel(booking.id)}
                                                        className="px-3 py-1.5 bg-red-500/20 hover:bg-red-500/30 text-red-400 rounded-lg text-sm transition-colors"
                                                    >
                                                        Cancel
                                                    </button>
                                                )}
                                            </td>
                                        </tr>
                                    ))
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>

                {/* Pagination */}
                {pagination && pagination.totalPages > 1 && (
                    <div className="flex items-center justify-between border-t border-gray-700 pt-6">
                        <div className="text-sm text-gray-400">
                            Showing page <span className="font-medium text-white">{pagination.page}</span> of <span className="font-medium text-white">{pagination.totalPages}</span>
                        </div>
                        <div className="flex gap-2">
                            <button
                                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                                disabled={currentPage === 1}
                                className="px-4 py-2 bg-gray-800 text-gray-300 rounded-lg hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                            >
                                Previous
                            </button>
                            <button
                                onClick={() => setCurrentPage(p => Math.min(pagination.totalPages, p + 1))}
                                disabled={currentPage === pagination.totalPages}
                                className="px-4 py-2 bg-gray-800 text-gray-300 rounded-lg hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                            >
                                Next
                            </button>
                        </div>
                    </div>
                )}
            </main>
        </div>
    );
}
