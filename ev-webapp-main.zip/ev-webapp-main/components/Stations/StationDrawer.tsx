'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { useStationsStore } from '@/store/stationsStore';
import { useBookingsStore } from '@/store/bookingsStore';
import { useRouteStore } from '@/store/routeStore';
import { useMapStore } from '@/store/mapStore';
import { directionsService } from '@/services/directionsService';
import { useState, useEffect } from 'react';
import { addMinutes } from 'date-fns';
import { useMobileUIStore } from '@/store/mobileUIStore';
import CarSearchInput from '@/components/Booking/CarSearchInput';

type BookingStep = 'details' | 'booking' | 'processing' | 'confirmed';

export default function StationDrawer() {
    const { selectedStation, setSelectedStation } = useStationsStore();
    const { createBooking, confirmBooking, extendBooking, activeBooking } = useBookingsStore();

    const [selectedConnector, setSelectedConnector] = useState<string | null>(null);
    const [step, setStep] = useState<BookingStep>('details');
    const [duration, setDuration] = useState(30);
    const [slotStart, setSlotStart] = useState(new Date().toISOString());
    const [timeLeft, setTimeLeft] = useState<string>('');
    const [vehicleModel, setVehicleModel] = useState('');

    // Check if this station has an active booking
    const hasActiveBooking = activeBooking?.stationId === selectedStation?.id && activeBooking?.status === 'CONFIRMED';

    // Countdown timer for active booking
    useEffect(() => {
        if (!hasActiveBooking || !activeBooking) {
            setTimeLeft('');
            return;
        }

        // Always show countdown to slotEnd (when charging session ends)
        // This includes arrival time + charging duration, and updates when extended
        const updateTimer = () => {
            const endTime = new Date(activeBooking.slotEnd).getTime();
            const diff = endTime - Date.now();

            if (diff <= 0) {
                setTimeLeft('Completed');
                return;
            }
            const mins = Math.floor(diff / 60000);
            const secs = Math.floor((diff % 60000) / 1000);
            setTimeLeft(`${mins}:${secs.toString().padStart(2, '0')}`);
        };

        updateTimer();
        const interval = setInterval(updateTimer, 1000);
        return () => clearInterval(interval);
    }, [hasActiveBooking, activeBooking, activeBooking?.slotEnd]);

    // Reset step when station changes
    useEffect(() => {
        if (hasActiveBooking) {
            setStep('confirmed');
        } else {
            setStep('details');
        }
        setSelectedConnector(null);
    }, [selectedStation?.id, hasActiveBooking]);

    const [realTimeDuration, setRealTimeDuration] = useState<string | null>(null);

    const handleClose = () => {
        setSelectedStation(null);
        setSelectedConnector(null);
        setStep('details');
        setRealTimeDuration(null);
    };

    // Calculate real-time travel duration when station is selected
    useEffect(() => {
        if (!selectedStation) return;

        const calculateTime = async () => {
            const userLocation = useMapStore.getState().userLocation;
            if (!userLocation) return;

            try {
                const route = await directionsService.getRouteInfo(
                    { lat: userLocation.position.lat, lng: userLocation.position.lng },
                    selectedStation.location,
                    useRouteStore.getState().travelMode || 'DRIVING'
                );

                if (route && route.durationText) {
                    setRealTimeDuration(route.durationText);
                }
            } catch (err) {
                console.warn("Failed to get real-time duration", err);
            }
        };

        calculateTime();
    }, [selectedStation]);

    const handleBookClick = () => {
        if (!selectedConnector) return;
        setStep('booking');
    };

    const handleConfirmBooking = async () => {
        try {
            console.log('handleConfirmBooking called');

            if (!selectedStation) {
                console.error('No selected station');
                return;
            }

            // 1. Get User ID
            const storedUser = localStorage.getItem('userInfo');
            const user = storedUser ? JSON.parse(storedUser) : null;

            console.log('User check:', { user });

            if (!user || !user.id) {
                // Trigger Auth Modal via global store
                useMobileUIStore.getState().setAuthModalOpen(true);
                setStep('booking');
                return;
            }

            setStep('processing');
            console.log('Set step to processing, calling createBooking...');

            // Calculate Travel Time
            let travelTimeMinutes = 0;
            const userLocation = useMapStore.getState().userLocation;
            if (userLocation) {
                try {
                    const route = await directionsService.getRouteInfo(
                        { lat: userLocation.position.lat, lng: userLocation.position.lng },
                        selectedStation.location,
                        useRouteStore.getState().travelMode || 'DRIVING'
                    );
                    if (route && route.legs && route.legs.length > 0 && route.legs[0].duration) {
                        // duration is in seconds
                        travelTimeMinutes = Math.ceil(route.legs[0].duration / 60);
                        console.log(`Calculated travel time: ${travelTimeMinutes} mins`);
                        // Force update local state if we want to show it in UI before booking?
                        // Ideally we should calculate this BEFORE the 'handleConfirmBooking' in a useEffect when station is selected
                    }
                } catch (err) {
                    console.warn('Failed to calculate travel time:', err);
                }
            }

            if (travelTimeMinutes > 60) {
                if (!confirm(`Travel time is estimated at ${Math.floor(travelTimeMinutes / 60)}h ${travelTimeMinutes % 60}m. Proceed?`)) {
                    setStep('booking');
                    return;
                }
            }

            const booking = await createBooking({
                stationId: selectedStation.id,
                userId: user.id,
                slotStart,
                durationMinutes: duration,
                travelTimeMinutes, // Dynamic start time
                vehicleModel: vehicleModel || 'Unknown Vehicle',
                stationData: {
                    name: selectedStation.name,
                    location: selectedStation.location,
                    address: selectedStation.address || 'Unknown Address',
                }
            } as any);

            console.log('Booking response:', booking);

            if (booking) {
                // Simulate payment processing delay
                setTimeout(async () => {
                    try {
                        const success = await confirmBooking(booking.id);
                        console.log('Confirm booking result:', success);

                        if (success) {
                            setStep('confirmed');
                            useStationsStore.getState().updateStationStatus(selectedStation.id, 'booked');
                        } else {
                            throw new Error('Payment confirmation failed');
                        }
                    } catch (innerError) {
                        console.error('Confirmation error:', innerError);
                        setStep('booking');
                        alert('Booking payment failed. Please try again.');
                    }
                }, 2000);
            } else {
                throw new Error('Booking creation returned null');
            }
        } catch (error: any) {
            console.error('Booking Error:', error);
            setStep('booking');
            // Extract error message from axios response if available
            const msg = error?.response?.data?.error || error.message || 'Unknown error occurred';
            alert(`Booking Failed: ${msg}`);
        }
    };

    const handleTrackNow = async () => {
        if (!selectedStation) return;

        const userLocation = useMapStore.getState().userLocation;
        if (!userLocation) {
            alert("User location not found, cannot route.");
            return;
        }

        // Set destination and show travel mode selector
        useRouteStore.getState().setDestination(selectedStation);
        useRouteStore.getState().setShowModeSelector(true);

        // Get initial route preview with default mode
        const route = await directionsService.getRouteInfo(
            { lat: userLocation.position.lat, lng: userLocation.position.lng },
            selectedStation.location,
            useRouteStore.getState().travelMode
        );

        if (route) {
            useRouteStore.getState().setPreviewRoute(route);
        }

        handleClose();
    };

    return (
        <AnimatePresence>
            {selectedStation && (
                <>
                    {/* Backdrop */}
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-30"
                        onClick={handleClose}
                    />

                    {/* Drawer */}
                    <motion.div
                        initial={{ x: '100%' }}
                        animate={{ x: 0 }}
                        exit={{ x: '100%' }}
                        transition={{ type: 'spring', damping: 30, stiffness: 300 }}
                        className="fixed top-0 right-0 h-full w-full max-w-md bg-gradient-to-b from-white to-gray-50 dark:from-gray-900 dark:to-gray-800 shadow-2xl z-50 overflow-y-auto"
                    >
                        {/* Header with gradient */}
                        <div className="relative bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 p-6 pb-8">
                            <button
                                onClick={handleClose}
                                className="absolute top-4 right-4 p-2 bg-white/20 hover:bg-white/30 rounded-full transition-colors"
                            >
                                <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                </svg>
                            </button>

                            {/* Station Icon */}
                            <div className="w-16 h-16 bg-white/20 backdrop-blur rounded-2xl flex items-center justify-center mb-4">
                                <span className="text-3xl">⚡</span>
                            </div>

                            <h2 className="text-2xl font-bold text-white mb-1">
                                {selectedStation.name}
                            </h2>
                            <p className="text-white/80 text-sm">
                                {selectedStation.address}
                            </p>

                            <div className="flex flex-wrap items-center gap-2 mt-2 text-white/90 text-sm font-medium">
                                {realTimeDuration && (
                                    <span className="flex items-center gap-1 bg-white/20 px-2 py-1 rounded-lg">
                                        ⏱️ {realTimeDuration} away
                                    </span>
                                )}
                                <span className={`px-3 py-1 rounded-full text-xs font-bold ${selectedStation.status === 'available' ? 'bg-green-400 text-green-900' :
                                    selectedStation.status === 'booked' ? 'bg-black text-primary-400 border border-primary-500 shadow-gold-glow' :
                                        'bg-gray-800 text-gray-400 border border-gray-700'
                                    }`}>
                                    {selectedStation.status.toUpperCase()}
                                </span>
                            </div>
                        </div>

                        {/* Content Area */}
                        <div className="p-6 space-y-6 -mt-4">
                            {/* Quick Stats Card */}
                            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-4 grid grid-cols-3 gap-4">
                                <div className="text-center">
                                    <div className="text-2xl font-bold text-blue-600">{selectedStation.rating}</div>
                                    <div className="text-xs text-gray-500">Rating</div>
                                </div>
                                <div className="text-center border-x border-gray-200 dark:border-gray-700">
                                    <div className="text-2xl font-bold text-green-600">{selectedStation.connectors.length}</div>
                                    <div className="text-xs text-gray-500">Ports</div>
                                </div>
                                <div className="text-center">
                                    <div className="text-2xl font-bold text-purple-600">{selectedStation.operatingHours}</div>
                                    <div className="text-xs text-gray-500">Hours</div>
                                </div>
                            </div>

                            {/* Active Booking Timer */}
                            {hasActiveBooking && step === 'confirmed' && (
                                <motion.div
                                    initial={{ scale: 0.9, opacity: 0 }}
                                    animate={{ scale: 1, opacity: 1 }}
                                    className="bg-gradient-to-r from-green-500 to-emerald-500 rounded-2xl p-6 text-white shadow-lg"
                                >
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <div className="text-sm opacity-80">Slot Reserved</div>
                                            <div className="text-4xl font-mono font-bold">{timeLeft}</div>
                                            <div className="text-xs opacity-70 mt-1">until end</div>
                                        </div>
                                        <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
                                            <span className="text-3xl">✓</span>
                                        </div>
                                    </div>
                                    <button
                                        onClick={handleTrackNow}
                                        className="w-full mt-4 py-3 bg-white text-green-600 font-bold rounded-xl shadow-lg hover:bg-gray-100 transition flex items-center justify-center gap-2"
                                    >
                                        <span>🚀</span> Navigate
                                    </button>
                                </motion.div>
                            )}

                            {/* Connectors Section */}
                            {step === 'details' && (
                                <div>
                                    <h3 className="text-sm font-bold text-gray-900 dark:text-white mb-3 uppercase tracking-wider">
                                        Select Connector
                                    </h3>
                                    <div className="space-y-2">
                                        {selectedStation.connectors.map((connector) => (
                                            <motion.div
                                                key={connector.id}
                                                whileHover={{ scale: 1.02 }}
                                                whileTap={{ scale: 0.98 }}
                                                onClick={() => connector.available && setSelectedConnector(connector.id)}
                                                className={`p-4 rounded-xl cursor-pointer transition-all border-2 ${selectedConnector === connector.id
                                                    ? 'border-primary-500 bg-black shadow-gold-glow-lg border-2 scale-[1.02]'
                                                    : connector.available
                                                        ? 'border-gray-700 bg-gray-800 hover:border-primary-500/50 hover:bg-gray-750'
                                                        : 'border-gray-800 bg-gray-900 opacity-50 cursor-not-allowed'
                                                    }`}
                                            >
                                                <div className="flex items-center justify-between">
                                                    <div className="flex items-center gap-3">
                                                        <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${selectedConnector === connector.id ? 'bg-gradient-to-br from-primary-400 to-primary-600 text-black font-bold shadow-lg' : 'bg-gray-700 text-gray-400'
                                                            }`}>
                                                            <span className="text-xl">🔌</span>
                                                        </div>
                                                        <div>
                                                            <div className="font-semibold text-gray-900 dark:text-white">{connector.type}</div>
                                                            <div className="text-sm text-gray-500">{connector.power} kW</div>
                                                        </div>
                                                    </div>
                                                    <div className="text-right">
                                                        <div className="font-bold text-gray-900 dark:text-white">₹{connector.price}/kWh</div>
                                                        <span className={`text-xs font-bold ${connector.available ? 'text-green-500' : 'text-red-500'}`}>
                                                            {connector.available ? '● Available' : '● In Use'}
                                                        </span>
                                                    </div>
                                                </div>
                                            </motion.div>
                                        ))}
                                    </div>
                                </div>
                            )}

                            {/* Booking Form */}
                            {step === 'booking' && (
                                <motion.div
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    className="space-y-6"
                                >
                                    {/* Vehicle Selection */}
                                    <div>
                                        <label className="block text-sm font-bold text-gray-900 dark:text-white mb-2 uppercase tracking-wider">
                                            Select Your Vehicle
                                        </label>
                                        <CarSearchInput
                                            value={vehicleModel}
                                            onChange={setVehicleModel}
                                        />
                                    </div>

                                    <div>
                                        <label className="block text-sm font-bold text-gray-900 dark:text-white mb-2 uppercase tracking-wider">
                                            Start Time
                                        </label>
                                        <select
                                            className="w-full p-4 bg-white dark:bg-gray-800 border-2 border-gray-200 dark:border-gray-700 rounded-xl focus:border-blue-500 outline-none transition"
                                            value={slotStart}
                                            onChange={(e) => setSlotStart(e.target.value)}
                                        >
                                            <option value={new Date().toISOString()}>Now</option>
                                            <option value={addMinutes(new Date(), 15).toISOString()}>In 15 minutes</option>
                                            <option value={addMinutes(new Date(), 30).toISOString()}>In 30 minutes</option>
                                        </select>
                                    </div>

                                    <div>
                                        <label className="block text-sm font-bold text-gray-900 dark:text-white mb-2 uppercase tracking-wider">
                                            Duration
                                        </label>
                                        <div className="grid grid-cols-4 gap-2">
                                            {[15, 30, 45, 60].map(m => (
                                                <button
                                                    key={m}
                                                    onClick={() => setDuration(m)}
                                                    className={`py-3 rounded-xl font-bold transition-all ${duration === m
                                                        ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg shadow-blue-500/30'
                                                        : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200'
                                                        }`}
                                                >
                                                    {m}m
                                                </button>
                                            ))}
                                        </div>
                                    </div>

                                    {/* Price Summary */}
                                    <div className="bg-gradient-to-r from-gray-100 to-gray-50 dark:from-gray-800 dark:to-gray-700 rounded-2xl p-4">
                                        <div className="flex justify-between items-center">
                                            <span className="text-gray-600 dark:text-gray-400">Estimated Total</span>
                                            <span className="text-3xl font-bold text-gray-900 dark:text-white">
                                                ₹{((duration / 60) * 150).toFixed(0)}
                                            </span>
                                        </div>
                                    </div>

                                    {/* Action Buttons */}
                                    <div className="flex gap-3">
                                        <button
                                            onClick={() => setStep('details')}
                                            className="flex-1 py-4 text-gray-600 dark:text-gray-400 font-medium rounded-xl border-2 border-gray-200 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800 transition"
                                        >
                                            Back
                                        </button>
                                        <button
                                            onClick={handleConfirmBooking}
                                            className="flex-1 py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-bold rounded-xl shadow-lg shadow-blue-500/30 hover:shadow-xl transition"
                                        >
                                            Confirm Booking
                                        </button>
                                    </div>
                                </motion.div>
                            )}

                            {/* Processing State */}
                            {step === 'processing' && (
                                <motion.div
                                    initial={{ opacity: 0 }}
                                    animate={{ opacity: 1 }}
                                    className="py-12 text-center"
                                >
                                    <div className="w-20 h-20 mx-auto mb-6 relative">
                                        <div className="absolute inset-0 bg-primary-500/20 rounded-full animate-ping shadow-gold-glow"></div>
                                        <div className="relative w-full h-full bg-gradient-to-r from-primary-600 to-primary-400 rounded-full flex items-center justify-center shadow-gold-glow overflow-hidden">
                                            <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/30 to-transparent skew-x-12 animate-shine opacity-50"></div>
                                            <div className="animate-spin w-8 h-8 border-3 border-black border-t-transparent rounded-full z-10"></div>
                                        </div>
                                    </div>
                                    <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Processing Payment</h3>
                                    <p className="text-gray-500">Securing your charging slot...</p>
                                </motion.div>
                            )}

                            {/* Confirmed State - Success with Track Now */}
                            {step === 'confirmed' && (
                                <motion.div
                                    initial={{ opacity: 0, scale: 0.9 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    className="py-8 text-center"
                                >
                                    <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-r from-green-500 to-emerald-400 rounded-full flex items-center justify-center shadow-lg shadow-green-500/40">
                                        <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                                        </svg>
                                    </div>
                                    <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Booking Confirmed! 🎉</h3>
                                    <p className="text-gray-500 mb-6">Your charging slot is reserved</p>

                                    {timeLeft && (
                                        <div className="bg-black border border-primary-500 text-primary-400 px-4 py-2 rounded-xl mb-6 shadow-gold-glow">
                                            <span className="font-medium">Time remaining: </span>
                                            <span className="font-mono font-bold">{timeLeft}</span>
                                        </div>
                                    )}

                                    <button
                                        onClick={handleTrackNow}
                                        className="w-full py-4 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white font-bold rounded-xl shadow-lg shadow-blue-500/30 hover:shadow-xl transition-all text-lg flex items-center justify-center gap-2"
                                    >
                                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
                                        </svg>
                                        🚗 Track Now - Get Directions
                                    </button>
                                </motion.div>
                            )}

                            {/* Amenities - Show only in details/confirmed step */}
                            {(step === 'details' || step === 'confirmed') && (
                                <div>
                                    <h3 className="text-sm font-bold text-gray-900 dark:text-white mb-3 uppercase tracking-wider">
                                        Amenities
                                    </h3>
                                    <div className="flex flex-wrap gap-2">
                                        {selectedStation.amenities.wifi && (
                                            <span className="px-4 py-2 bg-gray-800 border border-primary-500/30 text-primary-300 rounded-xl text-sm font-medium shadow-3d-hover">
                                                📶 WiFi
                                            </span>
                                        )}
                                        {selectedStation.amenities.restaurant && (
                                            <span className="px-4 py-2 bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-300 rounded-xl text-sm font-medium">
                                                🍽️ Restaurant
                                            </span>
                                        )}
                                        {selectedStation.amenities.restroom && (
                                            <span className="px-4 py-2 bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 rounded-xl text-sm font-medium">
                                                🚻 Restroom
                                            </span>
                                        )}
                                        {selectedStation.amenities.parking && (
                                            <span className="px-4 py-2 bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300 rounded-xl text-sm font-medium">
                                                🅿️ Parking
                                            </span>
                                        )}
                                        {selectedStation.amenities.shelter && (
                                            <span className="px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-xl text-sm font-medium">
                                                🏠 Shelter
                                            </span>
                                        )}
                                    </div>
                                </div>
                            )}

                            {/* Book Button - Details Step */}
                            {step === 'details' && !hasActiveBooking && (
                                <motion.button
                                    whileHover={{ scale: 1.02 }}
                                    whileTap={{ scale: 0.98 }}
                                    onClick={handleBookClick}
                                    disabled={!selectedConnector || selectedStation.status !== 'available'}
                                    className="w-full py-4 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white font-bold rounded-xl shadow-lg shadow-blue-500/30 hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed transition-all text-lg"
                                >
                                    {selectedConnector ? '⚡ Book This Slot' : 'Select a Connector'}
                                </motion.button>
                            )}

                            <p className="text-xs text-center text-gray-400">
                                Demo Mode • Booking expires in 5 minutes
                            </p>
                        </div>
                    </motion.div>
                </>
            )}
        </AnimatePresence>
    );
}
