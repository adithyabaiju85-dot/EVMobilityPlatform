// Mock charging station data generator
const connectorTypes = ['CCS', 'CHAdeMO', 'Type2', 'Tesla'];
const speeds = ['slow', 'fast', 'ultra-fast'];
const operators = ['ChargePoint', 'EVgo', 'Electrify America', 'Tesla Supercharger', 'Shell Recharge'];

// Major Indian cities with coordinates
const cities = [
    { name: 'Delhi', lat: 28.6139, lng: 77.2090 },
    { name: 'Mumbai', lat: 19.0760, lng: 72.8777 },
    { name: 'Bangalore', lat: 12.9716, lng: 77.5946 },
    { name: 'Hyderabad', lat: 17.3850, lng: 78.4867 },
    { name: 'Chennai', lat: 13.0827, lng: 80.2707 },
    { name: 'Kolkata', lat: 22.5726, lng: 88.3639 },
    { name: 'Pune', lat: 18.5204, lng: 73.8567 },
    { name: 'Ahmedabad', lat: 23.0225, lng: 72.5714 },
];

function generateStations(count = 50) {
    const stations = [];

    for (let i = 0; i < count; i++) {
        const city = cities[Math.floor(Math.random() * cities.length)];
        const speed = speeds[Math.floor(Math.random() * speeds.length)];

        // Generate random location near city center
        const lat = city.lat + (Math.random() - 0.5) * 0.2;
        const lng = city.lng + (Math.random() - 0.5) * 0.2;

        // Generate connectors based on speed
        const numConnectors = speed === 'ultra-fast' ? 4 : speed === 'fast' ? 3 : 2;
        const connectors = [];

        for (let j = 0; j < numConnectors; j++) {
            const type = connectorTypes[Math.floor(Math.random() * connectorTypes.length)];
            const power = speed === 'ultra-fast' ? 150 + Math.random() * 200 :
                speed === 'fast' ? 50 + Math.random() * 100 :
                    7 + Math.random() * 15;

            connectors.push({
                id: `${i}-${j}`,
                type,
                power: Math.round(power),
                available: Math.random() > 0.3,
                price: Math.round((5 + Math.random() * 10) * 100) / 100,
            });
        }

        const operator = operators[Math.floor(Math.random() * operators.length)];
        const statuses = ['available', 'busy', 'offline'];
        const status = statuses[Math.floor(Math.random() * statuses.length)];

        stations.push({
            id: `station-${i}`,
            name: `${operator} ${city.name} ${i + 1}`,
            location: { lat, lng },
            address: `${Math.floor(Math.random() * 999) + 1} Main Street, ${city.name}`,
            status,
            connectors,
            amenities: {
                restroom: Math.random() > 0.5,
                restaurant: Math.random() > 0.6,
                wifi: Math.random() > 0.3,
                parking: Math.random() > 0.2,
                shelter: Math.random() > 0.4,
            },
            rating: Math.round((3.5 + Math.random() * 1.5) * 10) / 10,
            reviews: Math.floor(Math.random() * 500) + 10,
            operatingHours: '24/7',
            operator,
            speed,
        });
    }

    return stations;
}

// Generate initial stations
let stations = generateStations(50);

function getAllStations() {
    return stations;
}

function getStationById(id) {
    return stations.find(s => s.id === id);
}

function updateStationStatus(id, status) {
    const station = stations.find(s => s.id === id);
    if (station) {
        station.status = status;
        return station;
    }
    return null;
}

function searchStations(query) {
    const lowerQuery = query.toLowerCase();
    return stations.filter(s =>
        s.name.toLowerCase().includes(lowerQuery) ||
        s.address.toLowerCase().includes(lowerQuery) ||
        s.operator.toLowerCase().includes(lowerQuery)
    );
}

module.exports = {
    getAllStations,
    getStationById,
    updateStationStatus,
    searchStations,
};
